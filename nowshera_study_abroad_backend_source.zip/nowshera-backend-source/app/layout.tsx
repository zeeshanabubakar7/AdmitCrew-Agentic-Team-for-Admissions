import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Nowshera Study Abroad | Student Support",
  description: "Explore the office study options, share your details, and follow your inquiry with Nowshera Study Abroad Consultants.",
  other: {
    "codex-preview": "development",
  },
  robots: { index: false, follow: false },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <meta name="referrer" content="no-referrer" />
      </head>
      <body className="antialiased">{children}</body>
    </html>
  );
}
