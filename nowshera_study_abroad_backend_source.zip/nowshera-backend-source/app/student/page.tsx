import StudentPortal from "./student-portal";

export const dynamic = "force-dynamic";

export default function StudentPage() {
  return <StudentPortal />;
}
