"use client";

import { ArrowLeft, ArrowRight, CheckCircle2, FileCheck2, FileText, LockKeyhole, Send } from "lucide-react";
import { FormEvent, useCallback, useEffect, useState } from "react";

type PortalData = {
  lead: { id:number; name:string; email:string; country:string; marks:number|null; ielts:string; stage:string };
  messages: {id:number;sender:string;body:string;status:string;kind:string;createdAt:string}[];
  documents: {id:number;docType:string;fileName:string;mimeType:string;demoPath:string|null;checkStatus:string;checkNote:string;reviewStatus:string;rejectionReason:string|null;createdAt:string}[];
  followups: {id:number;title:string;dueAt:string;status:string}[];
};

async function request<T>(url:string,init:RequestInit={}):Promise<T>{
  const headers=new Headers(init.headers);
  if(init.body&&!(init.body instanceof FormData)&&!headers.has("Content-Type"))headers.set("Content-Type","application/json");
  const response=await fetch(url,{...init,headers,cache:"no-store"});
  const data=await response.json().catch(()=>({})) as {error?:string};
  if(!response.ok)throw new Error(data.error??"Request could not be completed.");
  return data as T;
}

function date(value:string){const d=new Date(value);return Number.isNaN(d.getTime())?value:new Intl.DateTimeFormat("en-GB",{dateStyle:"medium",timeZone:"Asia/Karachi"}).format(d);}

export default function StudentPortal(){
  const [token,setToken]=useState("");const [data,setData]=useState<PortalData|null>(null);const [loading,setLoading]=useState(true);const [error,setError]=useState("");const [message,setMessage]=useState("");const [sending,setSending]=useState(false);const [notice,setNotice]=useState("");
  const [docType,setDocType]=useState("Passport");const [nameOnDocument,setNameOnDocument]=useState("");const [expiresOn,setExpiresOn]=useState("");const [overallScore,setOverallScore]=useState("");const [file,setFile]=useState<File|null>(null);const [uploading,setUploading]=useState(false);
  const load=useCallback(async(currentToken:string)=>{
    try{const response=await request<PortalData>(`/api/portal?token=${encodeURIComponent(currentToken)}`);setData(response);setError("");}
    catch(e){setError(e instanceof Error?e.message:"Student page could not load.");setData(null);}
    finally{setLoading(false);}
  },[]);
  useEffect(()=>{const current=new URLSearchParams(window.location.search).get("token")??"";setToken(current);if(current)void load(current);else{setError("Open the private link provided after you submitted your inquiry.");setLoading(false);}},[load]);
  async function sendMessage(e:FormEvent){e.preventDefault();if(!token)return;setSending(true);setNotice("");try{const result=await request<{notice:string}>("/api/portal/messages",{method:"POST",body:JSON.stringify({token,message})});setMessage("");setNotice(result.notice);await load(token);}catch(e){setNotice(e instanceof Error?e.message:"Message could not be saved.");}finally{setSending(false);}}
  async function upload(e:FormEvent){e.preventDefault();if(!token||!file)return;setUploading(true);setNotice("");const body=new FormData();body.append("token",token);body.append("file",file);body.append("docType",docType);body.append("nameOnDocument",nameOnDocument);body.append("expiresOn",expiresOn);body.append("overallScore",overallScore);try{const result=await request<{checkNote:string;reviewStatus:string}>("/api/portal/documents",{method:"POST",body});setNotice(`${result.checkNote} Staff review status: ${result.reviewStatus}.`);setFile(null);setNameOnDocument("");setExpiresOn("");setOverallScore("");const input=document.getElementById("student-file") as HTMLInputElement|null;if(input)input.value="";await load(token);}catch(e){setNotice(e instanceof Error?e.message:"File could not be saved.");}finally{setUploading(false);}}

  return <main className="min-h-screen bg-[#f3f5f1] px-4 py-6 text-[#173a40] sm:px-7 sm:py-10">
    <div className="mx-auto max-w-4xl">
      <a href="/" className="inline-flex min-h-10 items-center gap-2 rounded-xl px-2 text-sm font-bold text-[#557270] hover:bg-white"><ArrowLeft size={16}/> Nowshera Study Abroad</a>
      <header className="mt-6 rounded-[1.8rem] bg-[#15383e] p-6 text-white sm:p-9"><div className="flex items-start justify-between gap-4"><div><p className="text-xs font-bold uppercase tracking-[.14em] text-[#a8c9bd]">Private student page</p><h1 className="mt-3 font-serif text-3xl sm:text-4xl">{data?`Hello, ${data.lead.name.split(" ")[0]}.`:"Your study inquiry"}</h1><p className="mt-3 max-w-2xl text-sm leading-6 text-[#c4d8d5]">Ask the office a question, share a document, and check replies once a counselor approves them.</p></div><span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-white/10 text-[#c5e8d8]"><LockKeyhole size={20}/></span></div></header>
      {loading&&<div className="mt-5 rounded-2xl border border-[#dce5df] bg-white p-5 text-sm text-[#718581]">Loading your private page…</div>}
      {error&&!loading&&<div role="alert" className="mt-5 rounded-2xl border border-[#efd9ae] bg-[#fff7e5] p-5 text-sm leading-6 text-[#765821]">{error}</div>}
      {data&&<>
        <section className="mt-5 grid gap-4 sm:grid-cols-3">{[{label:"Destination",value:data.lead.country},{label:"Marks",value:data.lead.marks==null?"Not provided":`${data.lead.marks}%`},{label:"IELTS",value:data.lead.ielts}].map(item=><article key={item.label} className="rounded-2xl border border-[#dce5df] bg-white p-4"><p className="text-xs font-bold uppercase tracking-wide text-[#82938d]">{item.label}</p><p className="mt-2 font-serif text-xl text-[#294d51]">{item.value}</p></article>)}</section>
        <section className="mt-5 rounded-2xl border border-[#dce5df] bg-white p-5 sm:p-6"><div className="flex items-center justify-between gap-2"><div><p className="eyebrow">Conversation</p><h2 className="mt-1 font-serif text-2xl">Messages from the office</h2></div><span className="grid h-9 w-9 place-items-center rounded-xl bg-[#eaf2ec] text-[#4e7661]"><CheckCircle2 size={17}/></span></div>
          <p className="mt-2 text-xs leading-5 text-[#82918d]">Draft replies stay hidden here until a staff member approves them.</p>
          <div className="mt-4 max-h-[360px] space-y-2 overflow-y-auto">{data.messages.length?data.messages.map(m=><div key={m.id} className={`rounded-xl p-3.5 ${m.sender==="agent"?"bg-[#edf5ee]":"bg-[#f7f9f6]"}`}><div className="text-xs font-extrabold capitalize text-[#5c7771]">{m.sender==="agent"?"Office reply":"You"} · {date(m.createdAt)}</div><p className="mt-2 whitespace-pre-wrap text-sm leading-6 text-[#456163]">{m.body}</p></div>):<p className="rounded-xl bg-[#f8faf8] p-4 text-sm text-[#82918d]">No approved replies yet. You can send a question below.</p>}</div>
          <form onSubmit={sendMessage} className="mt-4"><label className="field-label" htmlFor="student-message">Ask a question</label><textarea id="student-message" className="form-control" maxLength={2000} value={message} onChange={e=>setMessage(e.target.value)} placeholder="Ask about a program, fee, deadline, marks, IELTS or documents" required/><div className="mt-3 flex flex-wrap items-center justify-between gap-3"><p className="max-w-lg text-xs leading-5 text-[#82918d]">The system drafts an answer from the office list. A counselor must approve it before it appears here.</p><button type="submit" disabled={sending||message.trim().length<2} className="inline-flex min-h-11 items-center gap-2 rounded-xl bg-[#1c4649] px-4 text-sm font-bold text-white hover:bg-[#12383c] disabled:opacity-50">{sending?"Saving…":"Send question"}<Send size={15}/></button></div></form>
          {notice&&<p role="status" className="mt-3 rounded-xl bg-[#eff6f0] px-3 py-2.5 text-sm text-[#426b52]">{notice}</p>}
        </section>
        <section className="mt-5 rounded-2xl border border-[#dce5df] bg-white p-5 sm:p-6"><div className="flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl bg-[#ebeff8] text-[#526b91]"><FileCheck2 size={18}/></span><div><p className="eyebrow">Application documents</p><h2 className="mt-1 font-serif text-2xl">Share a document</h2></div></div>
          <div className="mt-4 rounded-xl border border-[#eadcb9] bg-[#fff8e8] p-3.5 text-xs leading-5 text-[#765d32]">Use fake documents only for practice. Enter the name and date/score printed on the file. This form checks entered details; it does not read the PDF or image automatically. Staff must still verify the original.</div>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">{data.documents.map(d=><div key={d.id} className="rounded-xl border border-[#e5ece6] p-3.5"><div className="flex items-start justify-between gap-2"><div className="min-w-0"><p className="truncate text-sm font-bold text-[#3c5c5e]">{d.docType}</p><p className="mt-1 truncate text-xs text-[#7e908b]">{d.fileName}</p></div><span className={`rounded-full px-2 py-1 text-[11px] font-bold ${d.reviewStatus==="Verified"?"bg-[#e4f3e9] text-[#276247]":d.checkStatus==="problem"?"bg-[#fae4e0] text-[#98443a]":"bg-[#fff2d7] text-[#8b6222]"}`}>{d.reviewStatus}</span></div><p className="mt-2 text-xs leading-5 text-[#6f8380]">{d.rejectionReason||d.checkNote}</p><div className="mt-3">{d.demoPath?<a href={d.demoPath} target="_blank" rel="noreferrer" className="text-xs font-bold text-[#557b6c] underline underline-offset-4">Open practice PDF</a>:<a href={`/api/files/${d.id}?token=${encodeURIComponent(token)}`} target="_blank" rel="noreferrer" className="text-xs font-bold text-[#557b6c] underline underline-offset-4">Open uploaded file</a>}</div></div>)}</div>
          <form onSubmit={upload} className="mt-5 rounded-2xl bg-[#f7f9f6] p-4 sm:p-5"><div className="grid gap-3 sm:grid-cols-2"><label><span className="field-label">Document type</span><select className="form-control" value={docType} onChange={e=>setDocType(e.target.value)}>{["Passport","Transcript","IELTS result","Personal statement"].map(x=><option key={x}>{x}</option>)}</select></label><label><span className="field-label">Name on document</span><input className="form-control" value={nameOnDocument} onChange={e=>setNameOnDocument(e.target.value)} required/></label><label><span className="field-label">Passport expiry <span className="font-normal text-[#83928f]">(if passport)</span></span><input type="date" className="form-control" value={expiresOn} onChange={e=>setExpiresOn(e.target.value)}/></label><label><span className="field-label">IELTS overall <span className="font-normal text-[#83928f]">(if IELTS file)</span></span><input type="number" step="0.5" min="0" max="9" className="form-control" value={overallScore} onChange={e=>setOverallScore(e.target.value)} placeholder="e.g. 7.0"/></label></div>
            <label className="mt-3 block"><span className="field-label">PDF, JPG or PNG · max 5 MB</span><input id="student-file" type="file" accept=".pdf,.jpg,.jpeg,.png,application/pdf,image/jpeg,image/png" className="form-control h-auto py-2.5 file:mr-3 file:rounded-lg file:border-0 file:bg-[#e4efe7] file:px-3 file:py-2 file:text-xs file:font-bold file:text-[#416951]" onChange={e=>setFile(e.target.files?.[0]??null)} required/></label>
            <div className="mt-4 flex flex-wrap items-center justify-between gap-3"><p className="max-w-lg text-xs leading-5 text-[#82918d]">Accepted uploads are stored privately. Never upload a real passport or transcript for this project demo.</p><button type="submit" disabled={uploading||!file} className="inline-flex min-h-11 items-center gap-2 rounded-xl bg-[#1c4649] px-4 text-sm font-bold text-white hover:bg-[#12383c] disabled:opacity-50">{uploading?"Checking & uploading…":"Upload for review"}<ArrowRight size={15}/></button></div>
          </form>
        </section>
        {data.followups.length>0&&<section className="mt-5 rounded-2xl border border-[#dce5df] bg-white p-5"><p className="eyebrow">Next step</p>{data.followups.map(f=><p key={f.id} className="mt-2 text-sm text-[#56716e]">{f.title} · due {date(f.dueAt)}</p>)}</section>}
      </>}
      <footer className="mt-8 flex flex-wrap items-center justify-between gap-2 text-xs text-[#84938e]"><span>Private link · do not share it publicly</span><span>Practice data only · no admission promises</span></footer>
    </div>
  </main>;
}
