import { ensureSeedData, errorResponse } from "../lib/server";
import CRMClient from "./crm-client";

export const dynamic = "force-dynamic";

export default async function Home() {
  try {
    await ensureSeedData();
  } catch (error) {
    const message = error instanceof Error ? error.message : "The workspace is not ready yet.";
    return (
      <main className="min-h-screen bg-[#f3f5f1] p-8 text-[#15333a]">
        <section className="mx-auto max-w-xl rounded-3xl border border-[#dce5df] bg-white p-8 shadow-sm">
          <p className="eyebrow">Nowshera Study Abroad Consultants</p>
          <h1 className="mt-3 font-serif text-3xl">The workspace is setting up</h1>
          <p className="mt-3 text-[#60777a]">{message}</p>
          <p className="mt-5 text-sm text-[#60777a]">Refresh this page in a moment. No student details were submitted.</p>
        </section>
      </main>
    );
  }
  return <CRMClient />;
}
