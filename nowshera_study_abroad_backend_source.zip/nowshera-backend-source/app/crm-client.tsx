"use client";

import {
  ArrowRight,
  ArrowUpRight,
  Bell,
  BookOpen,
  Check,
  CheckCircle2,
  CircleAlert,
  Clock3,
  Database,
  FileCheck2,
  FileText,
  Globe2,
  GraduationCap,
  LayoutDashboard,
  LogIn,
  MailCheck,
  Plus,
  Search,
  Send,
  ShieldCheck,
  Users,
  X,
} from "lucide-react";
import { FormEvent, useCallback, useEffect, useMemo, useState } from "react";

type Session = {
  signedIn: boolean;
  authorized?: boolean;
  needsBootstrap?: boolean;
  email?: string;
  staff?: { userId: string; email: string; role: string };
};
type Program = {
  id: number; name: string; country: string; program: string; annualFee: string;
  deadline: string; minMarks: number; minIelts: number; documentsNeeded: string;
};
type Lead = {
  id: number; name: string; email: string; phone: string; country: string;
  marks: number | null; ielts: string; budget: string | null; source: string;
  stage: string; lastReplyAt: string; isDemo: number; createdAt: string;
};
type DocumentRow = {
  id: number; leadId: number; studentName: string; docType: string; fileName: string;
  mimeType: string; demoPath: string | null; checkStatus: string; checkNote: string;
  reviewStatus: string; rejectionReason: string | null; isDemo: number; createdAt: string;
};
type FollowUp = {
  id: number; leadId: number; studentName: string; country: string; lastReplyAt: string;
  title: string; dueAt: string; status: string; createdBy: string;
};
type MessageRow = {
  id: number; leadId: number; studentName: string; email: string; country: string;
  sender: string; body: string; status: string; kind: string; createdAt: string;
  approvedBy: string | null; approvedAt: string | null;
};
type DashboardData = {
  totalLeads: number; countries: { label: string; value: number }[];
  stages: { label: string; value: number }[]; pendingApprovals: number;
  pendingDocuments: number; quietStudents: number; deadlinesSoon: number;
};
type WorkspaceData = {
  dashboard: DashboardData; leads: Lead[]; programs: Program[];
  documents: DocumentRow[]; followups: FollowUp[]; messages: MessageRow[];
};

async function api<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  if (init.body && !(init.body instanceof FormData) && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }
  const response = await fetch(path, { ...init, headers, cache: "no-store" });
  const payload = await response.json().catch(() => ({})) as { error?: string; fields?: Record<string, string> };
  if (!response.ok) {
    const error = new Error(payload.error ?? "The request could not be completed.") as Error & { fields?: Record<string, string> };
    error.fields = payload.fields;
    throw error;
  }
  return payload as T;
}

function dateLabel(value?: string | null) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "short", year: "numeric", timeZone: "Asia/Karachi" }).format(date);
}

function since(value?: string | null) {
  if (!value) return "No reply yet";
  const days = Math.floor((Date.now() - new Date(value).getTime()) / 86_400_000);
  if (days <= 0) return "Today";
  if (days === 1) return "1 day ago";
  return `${days} days ago`;
}

function StatusPill({ children, tone = "neutral" }: { children: React.ReactNode; tone?: "neutral" | "good" | "warn" | "bad" | "dark" }) {
  const tones = {
    neutral: "bg-[#eff3ef] text-[#50696a]",
    good: "bg-[#e4f3e9] text-[#276247]",
    warn: "bg-[#fff2d7] text-[#8b6222]",
    bad: "bg-[#fae4e0] text-[#98443a]",
    dark: "bg-[#e0e9e8] text-[#25454a]",
  };
  return <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-bold ${tones[tone]}`}>{children}</span>;
}

function SolidButton({ children, onClick, type = "button", disabled = false, className = "" }: {
  children: React.ReactNode; onClick?: () => void; type?: "button" | "submit"; disabled?: boolean; className?: string;
}) {
  return <button type={type} onClick={onClick} disabled={disabled} className={`inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-[#1c4649] px-4 py-2.5 text-sm font-bold text-white shadow-sm transition hover:bg-[#12383c] disabled:cursor-not-allowed disabled:opacity-55 ${className}`}>{children}</button>;
}

function OutlineButton({ children, onClick, disabled = false, className = "" }: {
  children: React.ReactNode; onClick?: () => void; disabled?: boolean; className?: string;
}) {
  return <button type="button" onClick={onClick} disabled={disabled} className={`inline-flex min-h-10 items-center justify-center gap-2 rounded-xl border border-[#d8e3dd] bg-white px-3.5 py-2 text-sm font-semibold text-[#24474b] transition hover:border-[#98b9a8] hover:bg-[#f8faf8] disabled:opacity-50 ${className}`}>{children}</button>;
}

export default function CRMClient() {
  const [session, setSession] = useState<Session | null>(null);
  const [programs, setPrograms] = useState<Program[]>([]);
  const [loading, setLoading] = useState(true);
  const [pageError, setPageError] = useState("");
  const [toast, setToast] = useState("");
  const [workspace, setWorkspace] = useState<WorkspaceData | null>(null);
  const [activeSection, setActiveSection] = useState("overview");
  const [bootCode, setBootCode] = useState("");
  const [bootError, setBootError] = useState("");
  const [bootBusy, setBootBusy] = useState(false);

  const refreshSession = useCallback(async () => {
    const current = await api<Session>("/api/staff/session");
    setSession(current);
    return current;
  }, []);

  const loadWorkspace = useCallback(async () => {
    const [dashboard, leads, catalog, documents, followups, messages] = await Promise.all([
      api<DashboardData>("/api/staff/dashboard"),
      api<Lead[]>("/api/staff/leads"),
      api<Program[]>("/api/programs"),
      api<DocumentRow[]>("/api/staff/documents"),
      api<FollowUp[]>("/api/staff/followups"),
      api<MessageRow[]>("/api/staff/messages"),
    ]);
    setWorkspace({ dashboard, leads, programs: catalog, documents, followups, messages });
    setPrograms(catalog);
  }, []);

  useEffect(() => {
    let live = true;
    Promise.all([api<Session>("/api/staff/session"), api<Program[]>("/api/programs")])
      .then(([current, catalog]) => {
        if (!live) return;
        setSession(current);
        setPrograms(catalog);
      })
      .catch((error: unknown) => { if (live) setPageError(error instanceof Error ? error.message : "Workspace could not load."); })
      .finally(() => { if (live) setLoading(false); });
    return () => { live = false; };
  }, []);

  useEffect(() => {
    if (!session?.authorized) return;
    loadWorkspace().catch((error: unknown) => setPageError(error instanceof Error ? error.message : "Office data could not load."));
  }, [session?.authorized, loadWorkspace]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 4500);
    return () => window.clearTimeout(timer);
  }, [toast]);

  async function bootstrap(event: FormEvent) {
    event.preventDefault();
    setBootBusy(true);
    setBootError("");
    try {
      await api("/api/staff/bootstrap", { method: "POST", body: JSON.stringify({ setupCode: bootCode }) });
      setBootCode("");
      setToast("Office admin is ready.");
      await refreshSession();
    } catch (error) {
      setBootError(error instanceof Error ? error.message : "Admin setup could not be completed.");
    } finally {
      setBootBusy(false);
    }
  }

  if (loading) return <LoadingPage />;
  if (session?.authorized && !workspace) return <LoadingPage />;
  if (pageError && !session?.authorized) return <PublicSite programs={programs} startupError={pageError} />;
  if (session?.authorized && workspace) {
    return <Workspace
      session={session}
      workspace={workspace}
      activeSection={activeSection}
      setActiveSection={setActiveSection}
      reload={loadWorkspace}
      notice={setToast}
      toast={toast}
      loadError={pageError}
    />;
  }
  if (session?.signedIn && session.needsBootstrap) {
    return <BootstrapPage
      email={session.email ?? ""}
      code={bootCode}
      onCode={setBootCode}
      onSubmit={bootstrap}
      busy={bootBusy}
      error={bootError}
      onPublic={() => { window.location.href = "/#start"; }}
    />;
  }
  return <PublicSite
    programs={programs}
    startupError={pageError}
    signedInButNotStaff={Boolean(session?.signedIn && !session.authorized)}
    email={session?.email}
  />;
}

function LoadingPage() {
  return <main className="grid min-h-screen place-items-center bg-[#f3f5f1] p-6"><div className="flex items-center gap-3 rounded-2xl border border-[#dce5df] bg-white px-5 py-4 text-[#567276] shadow-sm"><span className="h-2.5 w-2.5 animate-pulse rounded-full bg-[#70a88d]" />Loading the Nowshera study options…</div></main>;
}

function BootstrapPage({ email, code, onCode, onSubmit, busy, error, onPublic }: {
  email: string; code: string; onCode: (value: string) => void; onSubmit: (event: FormEvent) => void;
  busy: boolean; error: string; onPublic: () => void;
}) {
  return <main className="grid min-h-screen place-items-center bg-[#edf3ee] px-4 py-10">
    <section className="w-full max-w-lg rounded-[2rem] border border-[#dce5df] bg-white p-7 shadow-[0_24px_75px_rgba(23,58,64,.1)] sm:p-10">
      <div className="grid h-12 w-12 place-items-center rounded-2xl bg-[#dcefe5] text-[#194448]"><ShieldCheck size={23} /></div>
      <p className="eyebrow mt-6">One-time office setup</p>
      <h1 className="mt-2 font-serif text-3xl leading-tight text-[#173a40]">Set up the first staff admin</h1>
      <p className="mt-3 text-sm leading-6 text-[#60777a]">Signed in as <strong className="text-[#284d52]">{email}</strong>. Enter the one-time setup code supplied to the office owner. The code can be used only while no admin account exists.</p>
      <form onSubmit={onSubmit} className="mt-7 space-y-4">
        <label className="block"><span className="field-label">Setup code</span><input autoComplete="one-time-code" className="form-control" value={code} onChange={(e) => onCode(e.target.value)} required /></label>
        {error && <p role="alert" className="rounded-xl bg-[#fff0ed] px-3 py-2 text-sm text-[#963e35]">{error}</p>}
        <SolidButton type="submit" disabled={busy} className="w-full">{busy ? "Setting up…" : "Create admin account"}<ArrowRight size={16} /></SolidButton>
      </form>
      <button onClick={onPublic} className="mt-5 text-sm font-semibold text-[#547275] underline decoration-[#bed1c6] underline-offset-4">Open the student information page</button>
    </section>
  </main>;
}

function PublicSite({ programs, startupError = "", signedInButNotStaff = false, email = "" }: {
  programs: Program[]; startupError?: string; signedInButNotStaff?: boolean; email?: string;
}) {
  const [search, setSearch] = useState("");
  const [country, setCountry] = useState("All countries");
  const [form, setForm] = useState({ name: "", email: "", phone: "", country: "UK", studyLevel: "Bachelor's", marks: "", ielts: "Not taken yet", budget: "", question: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [success, setSuccess] = useState<{ portalUrl: string; name: string; notice: string } | null>(null);
  const countries = useMemo(() => ["All countries", ...Array.from(new Set(programs.map((p) => p.country))).sort()], [programs]);
  const filtered = programs.filter((p) => {
    const term = search.toLowerCase();
    const matchesText = !term || `${p.name} ${p.program} ${p.country}`.toLowerCase().includes(term);
    return matchesText && (country === "All countries" || p.country === country);
  });

  async function submitInquiry(event: FormEvent) {
    event.preventDefault();
    setBusy(true); setError(""); setFieldErrors({});
    try {
      const result = await api<{ portalUrl: string; studentName: string; notice: string }>("/api/inquiries", { method: "POST", body: JSON.stringify(form) });
      setSuccess({ portalUrl: result.portalUrl, name: result.studentName, notice: result.notice });
    } catch (e) {
      const errorObject = e as Error & { fields?: Record<string, string> };
      setError(errorObject.message);
      if (errorObject.fields) setFieldErrors(errorObject.fields);
    } finally { setBusy(false); }
  }

  const set = (key: keyof typeof form, value: string) => setForm((current) => ({ ...current, [key]: value }));
  return <main className="min-h-screen bg-[#f3f5f1] text-[#173a40]">
    <header className="border-b border-[#dce5df] bg-[#f8faf7]">
      <div className="mx-auto flex max-w-[1320px] items-center justify-between gap-5 px-5 py-4 sm:px-8">
        <a href="#top" className="flex min-w-0 items-center gap-3" aria-label="Nowshera Study Abroad home">
          <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-[#1c4649] text-white"><GraduationCap size={22} /></span>
          <span className="min-w-0"><span className="block truncate text-[15px] font-extrabold tracking-tight">Nowshera Study Abroad</span><span className="mt-0.5 block text-xs text-[#648080]">Consultants · Student help desk</span></span>
        </a>
        <nav className="hidden items-center gap-7 text-sm font-semibold text-[#557174] md:flex">
          <a href="#programs" className="transition hover:text-[#173a40]">Study options</a>
          <a href="#how-it-works" className="transition hover:text-[#173a40]">How it works</a>
          <a href="#start" className="rounded-xl bg-[#e4efe8] px-4 py-2.5 text-[#20484c] hover:bg-[#d6e7dd]">Get guidance</a>
        </nav>
        <a href="/signin-with-chatgpt?return_to=/" target="_top" className="inline-flex min-h-10 items-center gap-2 rounded-xl border border-[#d6e1db] bg-white px-3 py-2 text-sm font-bold text-[#35585b] hover:bg-[#f7faf7]"><LogIn size={16} /><span className="hidden sm:inline">Staff sign in</span></a>
      </div>
    </header>

    {signedInButNotStaff && <div className="border-b border-[#ecd6aa] bg-[#fff6e3] px-5 py-3 text-center text-sm text-[#78561f]">{email} is not on the staff list. Ask the office admin to add this account.</div>}
    {startupError && <div className="border-b border-[#ecd6aa] bg-[#fff6e3] px-5 py-3 text-center text-sm text-[#78561f]">Study options are temporarily unavailable. Please refresh shortly.</div>}

    <section id="top" className="relative overflow-hidden bg-[#15383e] text-white">
      <div className="absolute -right-20 -top-28 h-[460px] w-[460px] rounded-full border border-white/10" />
      <div className="absolute -right-5 -top-12 h-[330px] w-[330px] rounded-full border border-white/10" />
      <div className="relative mx-auto grid max-w-[1320px] gap-9 px-5 py-12 sm:px-8 sm:py-16 lg:grid-cols-[1fr_390px] lg:items-center lg:gap-16 lg:py-20">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/5 px-3 py-1.5 text-xs font-bold tracking-wide text-[#c5e8d8]"><Globe2 size={14} /> UK · Canada · Germany · Australia · more</div>
          <h1 className="mt-6 max-w-3xl font-serif text-[2.65rem] leading-[1.08] tracking-tight sm:text-6xl">A clear first step for your study abroad plans.</h1>
          <p className="mt-5 max-w-2xl text-base leading-7 text-[#c4d8d5] sm:text-lg">Share your destination, marks and English test status once. Our office team will review your options and follow up with you.</p>
          <div className="mt-7 flex flex-wrap gap-3 text-sm text-[#e0eeea]">
            <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-2"><ShieldCheck size={15} className="text-[#b6e4cc]" /> Replies are reviewed by staff</span>
            <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-2"><BookOpen size={15} className="text-[#e5c58d]" /> Fees and dates are practice examples</span>
          </div>
        </div>

        <section id="start" className="scroll-mt-6 rounded-[1.7rem] border border-white/55 bg-[#fdfefb] p-5 text-[#173a40] shadow-[0_24px_60px_rgba(0,0,0,.2)] sm:p-6">
          {success ? <div className="py-3">
            <div className="grid h-12 w-12 place-items-center rounded-2xl bg-[#e4f3e9] text-[#276247]"><CheckCircle2 size={25} /></div>
            <p className="eyebrow mt-6">Inquiry saved</p>
            <h2 className="mt-2 font-serif text-3xl">Thank you, {success.name.split(" ")[0]}.</h2>
            <p className="mt-3 text-sm leading-6 text-[#617779]">{success.notice}</p>
            <div className="mt-6 rounded-2xl bg-[#eef5ef] p-4">
              <p className="text-sm font-bold text-[#274d51]">Your private student link</p>
              <p className="mt-1 text-xs leading-5 text-[#617779]">Save this link. You can ask questions, share fake test documents, and view replies after staff approval.</p>
              <a href={success.portalUrl} className="mt-4 inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-xl bg-[#1c4649] px-4 py-2 text-sm font-bold text-white hover:bg-[#12383c]">Open your student page <ArrowRight size={16} /></a>
              <button onClick={() => navigator.clipboard?.writeText(success.portalUrl)} className="mt-3 w-full text-sm font-semibold text-[#496b6a] underline decoration-[#bed1c6] underline-offset-4">Copy private link</button>
            </div>
            <p className="mt-4 text-xs leading-5 text-[#738583]">A counselor will review the details. This page does not promise admission or visa approval.</p>
          </div> : <>
            <p className="eyebrow">Start with your details</p>
            <h2 className="mt-1.5 font-serif text-[1.8rem] leading-tight">Tell us what you’re planning.</h2>
            <p className="mt-2 text-sm leading-5 text-[#687d7c]">It takes about a minute. There is no account to create.</p>
            <form onSubmit={submitInquiry} className="mt-5 space-y-3.5">
              <div className="grid gap-3 sm:grid-cols-2">
                <label><span className="field-label">Full name</span><input className="form-control" autoComplete="name" value={form.name} onChange={(e) => set("name", e.target.value)} required />{fieldErrors.name && <ErrorText>{fieldErrors.name}</ErrorText>}</label>
                <label><span className="field-label">Phone number</span><input className="form-control" autoComplete="tel" inputMode="tel" placeholder="03xx xxxxxxx" value={form.phone} onChange={(e) => set("phone", e.target.value)} required />{fieldErrors.phone && <ErrorText>{fieldErrors.phone}</ErrorText>}</label>
              </div>
              <label className="block"><span className="field-label">Email address</span><input className="form-control" type="email" autoComplete="email" value={form.email} onChange={(e) => set("email", e.target.value)} required />{fieldErrors.email && <ErrorText>{fieldErrors.email}</ErrorText>}</label>
              <div className="grid gap-3 sm:grid-cols-2">
                <label><span className="field-label">Country you’re considering</span><select className="form-control" value={form.country} onChange={(e) => set("country", e.target.value)}>{Array.from(new Set(programs.map((p) => p.country))).sort().map((item) => <option key={item}>{item}</option>)}</select></label>
                <label><span className="field-label">Study level</span><select className="form-control" value={form.studyLevel} onChange={(e) => set("studyLevel", e.target.value)}><option>Bachelor&apos;s</option><option>Master&apos;s</option></select></label>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <label><span className="field-label">Marks / percentage</span><input className="form-control" inputMode="decimal" placeholder="e.g. 78" value={form.marks} onChange={(e) => set("marks", e.target.value)} />{fieldErrors.marks && <ErrorText>{fieldErrors.marks}</ErrorText>}</label>
                <label><span className="field-label">IELTS overall</span><select className="form-control" value={form.ielts} onChange={(e) => set("ielts", e.target.value)}><option>Not taken yet</option>{["5.0","5.5","6.0","6.5","7.0","7.5","8.0","8.5","9.0"].map((x) => <option key={x}>{x}</option>)}</select></label>
              </div>
              <label className="block"><span className="field-label">Annual tuition budget <span className="font-normal text-[#83928f]">(optional)</span></span><input className="form-control" placeholder="e.g. up to £30,000" value={form.budget} onChange={(e) => set("budget", e.target.value)} /></label>
              <label className="block"><span className="field-label">What would you like to know? <span className="font-normal text-[#83928f]">(optional)</span></span><textarea className="form-control min-h-[78px]" placeholder="Fees, deadlines, marks, IELTS or documents" value={form.question} onChange={(e) => set("question", e.target.value)} /></label>
              {error && <p role="alert" className="rounded-xl bg-[#fff0ed] px-3 py-2.5 text-sm leading-5 text-[#963e35]">{error}</p>}
              <SolidButton type="submit" disabled={busy} className="w-full">{busy ? "Saving your inquiry…" : "Send inquiry to the office"}<ArrowRight size={17} /></SolidButton>
              <p className="text-center text-xs leading-5 text-[#81908d]">Your details are kept for the office to review. No reply is sent without staff approval.</p>
            </form>
          </>}
        </section>
      </div>
    </section>

    <section id="how-it-works" className="mx-auto grid max-w-[1320px] gap-4 px-5 py-8 sm:grid-cols-3 sm:px-8 sm:py-10">
      {[
        { number: "01", title: "Share your study profile", copy: "Tell the team your destination, marks, IELTS status and budget once.", icon: Users },
        { number: "02", title: "Check listed options", copy: "Browse the office’s program list, entry marks, fees, deadlines and documents.", icon: BookOpen },
        { number: "03", title: "Get a reviewed reply", copy: "A staff member checks every drafted response before it appears in your private page.", icon: ShieldCheck },
      ].map((step) => <article key={step.number} className="rounded-2xl border border-[#dce5df] bg-white p-5">
        <div className="flex items-center justify-between"><span className="text-xs font-extrabold tracking-[.14em] text-[#9aaea3]">{step.number}</span><step.icon size={19} className="text-[#638676]" /></div>
        <h3 className="mt-4 font-serif text-xl text-[#1d4146]">{step.title}</h3><p className="mt-2 text-sm leading-6 text-[#667c7c]">{step.copy}</p>
      </article>)}
    </section>

    <section id="programs" className="scroll-mt-8 border-t border-[#dce5df] bg-[#f8faf7]">
      <div className="mx-auto max-w-[1320px] px-5 py-10 sm:px-8 sm:py-14">
        <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
          <div><p className="eyebrow">Office university list</p><h2 className="mt-2 font-serif text-3xl sm:text-4xl">Explore the practice options.</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-[#667c7c]">These fees, requirements and dates are sample data for project testing. Confirm current details with the university before applying.</p></div>
          <div className="flex flex-col gap-3 sm:flex-row">
            <label className="relative block"><Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#7c9290]" /><input aria-label="Search programs" className="form-control min-w-[220px] pl-9" placeholder="University or program" value={search} onChange={(e) => setSearch(e.target.value)} /></label>
            <select aria-label="Filter by country" className="form-control sm:min-w-[170px]" value={country} onChange={(e) => setCountry(e.target.value)}>{countries.map((c) => <option key={c}>{c}</option>)}</select>
          </div>
        </div>
        {!programs.length ? <p className="mt-8 rounded-xl bg-white p-5 text-sm text-[#667c7c]">Program list is loading…</p> : <>
          <div className="mt-7 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {filtered.map((program) => <ProgramCard key={program.id} program={program} />)}
          </div>
          {!filtered.length && <p className="mt-8 rounded-xl border border-[#dce5df] bg-white p-6 text-sm text-[#667c7c]">No programs match that search.</p>}
        </>}
      </div>
    </section>
    <footer className="bg-[#173a40] px-5 py-7 text-sm text-[#d7e7e0]"><div className="mx-auto flex max-w-[1320px] flex-col gap-2 sm:flex-row sm:items-center sm:justify-between"><span className="font-bold">Nowshera Study Abroad Consultants</span><span className="text-xs text-[#afc5bf]">Practice data only · Staff approval required before replies are shared</span></div></footer>
  </main>;
}

function ErrorText({ children }: { children: React.ReactNode }) { return <span className="mt-1 block text-xs text-[#9c443c]">{children}</span>; }

function ProgramCard({ program }: { program: Program }) {
  return <article className="rounded-2xl border border-[#dce5df] bg-white p-5 transition hover:-translate-y-0.5 hover:shadow-[0_14px_34px_rgba(29,64,68,.08)]">
    <div className="flex items-start justify-between gap-3"><div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#e8f2eb] text-[#376451]"><GraduationCap size={18} /></div><StatusPill tone="dark">{program.country}</StatusPill></div>
    <h3 className="mt-4 font-serif text-xl leading-snug text-[#1c4247]">{program.name}</h3>
    <p className="mt-1 text-sm font-semibold text-[#607a7b]">{program.program}</p>
    <div className="mt-4 grid grid-cols-2 gap-3 border-t border-[#edf1ee] pt-4 text-sm">
      <div><p className="text-xs font-semibold uppercase tracking-wide text-[#849592]">Fee / year</p><p className="mt-1 font-bold text-[#294e52]">{program.annualFee}</p></div>
      <div><p className="text-xs font-semibold uppercase tracking-wide text-[#849592]">Deadline</p><p className="mt-1 font-bold text-[#294e52]">{dateLabel(program.deadline)}</p></div>
      <div><p className="text-xs font-semibold uppercase tracking-wide text-[#849592]">Minimum marks</p><p className="mt-1 font-bold text-[#294e52]">{program.minMarks}%</p></div>
      <div><p className="text-xs font-semibold uppercase tracking-wide text-[#849592]">IELTS</p><p className="mt-1 font-bold text-[#294e52]">{program.minIelts}</p></div>
    </div>
    <p className="mt-4 border-t border-[#edf1ee] pt-3 text-xs leading-5 text-[#728581]"><strong className="text-[#536f6e]">Documents:</strong> {program.documentsNeeded}</p>
  </article>;
}

const navItems = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "students", label: "Students", icon: Users },
  { id: "programs", label: "Programs", icon: GraduationCap },
  { id: "documents", label: "Documents", icon: FileCheck2 },
  { id: "followups", label: "Follow-ups", icon: Bell },
  { id: "approvals", label: "Approvals", icon: MailCheck },
  { id: "database", label: "Database", icon: Database },
  { id: "team", label: "Staff access", icon: ShieldCheck },
];

function Workspace({ session, workspace, activeSection, setActiveSection, reload, notice, toast, loadError }: {
  session: Session; workspace: WorkspaceData; activeSection: string; setActiveSection: (value: string) => void;
  reload: () => Promise<void>; notice: (value: string) => void; toast: string; loadError: string;
}) {
  const [busy, setBusy] = useState(false);
  const [search, setSearch] = useState("");
  const staff = session.staff!;
  const pending = workspace.messages.filter((m) => m.sender === "agent" && m.status === "pending_approval").length;

  async function action(path: string, method: string, body?: unknown, successText = "Saved.") {
    setBusy(true);
    try {
      await api(path, { method, body: body === undefined ? undefined : JSON.stringify(body) });
      await reload();
      notice(successText);
    } catch (e) { notice(e instanceof Error ? e.message : "Could not save that change."); }
    finally { setBusy(false); }
  }

  const visibleNavItems = navItems.filter((item) => item.id !== "team" || staff.role === "admin");
  const title = navItems.find((item) => item.id === activeSection)?.label ?? "Overview";
  return <div className="min-h-screen bg-[#f3f5f1] text-[#173a40] lg:grid lg:grid-cols-[248px_minmax(0,1fr)]">
    <aside className="hidden min-h-screen flex-col bg-[#15383e] px-4 py-5 text-white lg:flex">
      <a href="/" className="flex items-center gap-3 px-2 py-2"><span className="grid h-10 w-10 place-items-center rounded-xl bg-[#d8eee1] text-[#173a40]"><GraduationCap size={21} /></span><span><span className="block text-sm font-extrabold tracking-tight">Nowshera Study</span><span className="mt-0.5 block text-xs text-[#b6ccc6]">Abroad consultants</span></span></a>
      <div className="mt-9 px-3 text-[11px] font-bold uppercase tracking-[.14em] text-[#8faeaa]">Office workspace</div>
      <nav className="mt-3 space-y-1">
        {visibleNavItems.map((item) => <button key={item.id} onClick={() => setActiveSection(item.id)} className={`flex min-h-11 w-full items-center gap-3 rounded-xl px-3 text-left text-sm font-semibold transition ${activeSection === item.id ? "bg-[#dceee3] text-[#1b4649]" : "text-[#d0dfdb] hover:bg-white/8 hover:text-white"}`}><item.icon size={17} />{item.label}{item.id === "approvals" && pending > 0 && <span className={`ml-auto rounded-full px-2 py-0.5 text-xs ${activeSection === item.id ? "bg-[#c0dfcf] text-[#214d44]" : "bg-[#a36b35] text-white"}`}>{pending}</span>}</button>)}
      </nav>
      <div className="mt-auto rounded-2xl border border-white/10 bg-white/5 p-4">
        <div className="flex items-center gap-2 text-sm font-bold text-[#e3f0e9]"><ShieldCheck size={16} className="text-[#bddfc9]" /> Approval stays on</div>
        <p className="mt-2 text-xs leading-5 text-[#acc5be]">Agent drafts are visible to staff first. Only approved replies appear in a student portal.</p>
      </div>
    </aside>

    <div className="min-w-0">
      <header className="sticky top-0 z-30 border-b border-[#dce5df] bg-[#f9fbf8]/95 backdrop-blur">
        <div className="flex min-h-[72px] items-center justify-between gap-4 px-4 sm:px-7">
          <div className="flex min-w-0 items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl bg-[#dcefe5] text-[#254d4d] lg:hidden"><GraduationCap size={20} /></span><div><p className="eyebrow hidden sm:block">Office workspace</p><h1 className="truncate font-serif text-2xl leading-tight sm:mt-0.5">{title}</h1></div></div>
          <div className="flex items-center gap-2 sm:gap-3"><a href="/#programs" target="_blank" className="hidden min-h-10 items-center gap-2 rounded-xl border border-[#d6e1db] bg-white px-3 text-xs font-bold text-[#4e6e6e] hover:bg-[#f5f8f5] sm:inline-flex">Student page <ArrowUpRight size={14} /></a><div className="hidden h-9 w-px bg-[#dce5df] sm:block" /><span className="grid h-9 w-9 place-items-center rounded-full bg-[#e0eee5] text-sm font-extrabold text-[#315f50]">{staff.email.slice(0,1).toUpperCase()}</span><div className="hidden sm:block"><p className="text-xs font-bold text-[#34565a]">{staff.email}</p><p className="mt-0.5 text-[11px] capitalize text-[#788d89]">{staff.role}</p></div></div>
        </div>
        <nav className="thin-scrollbar flex gap-1 overflow-x-auto border-t border-[#e6ede8] px-3 py-2 lg:hidden">{visibleNavItems.map((item) => <button key={item.id} onClick={() => setActiveSection(item.id)} className={`flex shrink-0 items-center gap-2 rounded-lg px-3 py-2 text-xs font-bold ${activeSection === item.id ? "bg-[#dceee3] text-[#1b4649]" : "text-[#587274] hover:bg-white"}`}><item.icon size={15} />{item.label}</button>)}</nav>
      </header>
      <main className="mx-auto max-w-[1500px] px-4 py-6 sm:px-7 sm:py-8">
        {loadError && <div role="alert" className="mb-5 rounded-xl border border-[#efd9ae] bg-[#fff7e5] px-4 py-3 text-sm text-[#765821]">{loadError}</div>}
        {activeSection === "overview" && <Overview data={workspace} onNavigate={setActiveSection} />}
        {activeSection === "students" && <StudentsView data={workspace} query={search} setQuery={setSearch} reload={reload} notice={notice} busy={busy} action={action} />}
        {activeSection === "programs" && <ProgramsView programs={workspace.programs} reload={reload} notice={notice} action={action} isAdmin={staff.role === "admin"} busy={busy} />}
        {activeSection === "documents" && <DocumentsView documents={workspace.documents} action={action} busy={busy} />}
        {activeSection === "followups" && <FollowupsView rows={workspace.followups} action={action} busy={busy} reload={reload} notice={notice} />}
        {activeSection === "approvals" && <ApprovalsView messages={workspace.messages} action={action} busy={busy} />}
        {activeSection === "database" && <DatabaseView />}
        {activeSection === "team" && staff.role === "admin" && <TeamView />}
      </main>
    </div>
    {toast && <div role="status" className="fixed bottom-5 right-5 z-50 flex max-w-[min(480px,calc(100%-40px))] items-start gap-3 rounded-2xl bg-[#15383e] px-4 py-3 text-sm leading-5 text-white shadow-xl"><CheckCircle2 size={17} className="mt-0.5 shrink-0 text-[#bde4ca]" />{toast}<button aria-label="Dismiss" onClick={() => notice("")} className="ml-1 text-white/70 hover:text-white"><X size={15} /></button></div>}
  </div>;
}

function SectionIntro({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: React.ReactNode }) {
  return <div className="mb-6 flex flex-col gap-4 sm:mb-7 sm:flex-row sm:items-end sm:justify-between"><div><p className="eyebrow">{eyebrow}</p><h2 className="mt-1.5 font-serif text-3xl tracking-tight sm:text-[2.15rem]">{title}</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-[#6c8180]">{description}</p></div>{action}</div>;
}

function Overview({ data, onNavigate }: { data: WorkspaceData; onNavigate: (value: string) => void }) {
  const d = data.dashboard;
  const attention = data.leads.filter((l) => l.stage !== "Lost" && l.stage !== "Converted" && Date.now() - new Date(l.lastReplyAt).getTime() >= 3 * 86_400_000).sort((a,b)=>new Date(a.lastReplyAt).getTime()-new Date(b.lastReplyAt).getTime()).slice(0,4);
  const cards = [
    { label: "Student enquiries", value: d.totalLeads, note: "Saved in the office database", icon: Users, tone: "text-[#376451] bg-[#e6f2e9]" },
    { label: "Quiet for 3+ days", value: d.quietStudents, note: "Ready for a reminder draft", icon: Clock3, tone: "text-[#8a642c] bg-[#fff2d7]" },
    { label: "Documents to review", value: d.pendingDocuments, note: "Staff verification required", icon: FileCheck2, tone: "text-[#48628b] bg-[#ebeff8]" },
    { label: "Reply approvals", value: d.pendingApprovals, note: "No draft is sent automatically", icon: MailCheck, tone: "text-[#934f42] bg-[#f9e8e3]" },
  ];
  return <>
    <SectionIntro eyebrow="Saturday · 26 September 2026" title="A calm view of the office." description="Review new enquiries, document checks and drafts that need a staff decision." action={<a href="#programs" onClick={(e)=>{e.preventDefault();onNavigate("programs");}} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-[#1c4649] px-4 text-sm font-bold text-white hover:bg-[#12383c]">View university list <ArrowRight size={16} /></a>} />
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{cards.map((c) => <article key={c.label} className="rounded-2xl border border-[#dce5df] bg-white p-5 shadow-[0_5px_18px_rgba(31,66,66,.025)]"><div className="flex items-start justify-between"><span className={`grid h-10 w-10 place-items-center rounded-xl ${c.tone}`}><c.icon size={18} /></span><ArrowUpRight size={16} className="text-[#b4c2bb]" /></div><p className="mt-5 text-sm font-semibold text-[#6d8280]">{c.label}</p><p className="mt-1 font-serif text-4xl text-[#173a40]">{c.value}</p><p className="mt-2 text-xs text-[#82938e]">{c.note}</p></article>)}</div>
    <div className="mt-5 grid gap-5 xl:grid-cols-[1.35fr_.85fr]">
      <section className="rounded-2xl border border-[#dce5df] bg-white p-5 sm:p-6"><div className="flex items-center justify-between gap-3"><div><p className="eyebrow">Needs a look</p><h3 className="mt-1 font-serif text-2xl">Students who went quiet</h3></div><button onClick={()=>onNavigate("followups")} className="text-sm font-bold text-[#507874] hover:text-[#173a40]">Follow-ups <ArrowRight className="ml-1 inline" size={14} /></button></div>
        {attention.length ? <div className="mt-5 divide-y divide-[#edf1ee]">{attention.map((l)=><div key={l.id} className="flex flex-wrap items-center justify-between gap-3 py-3.5"><div className="flex min-w-0 items-center gap-3"><span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-[#e8f1eb] text-sm font-extrabold text-[#3a6457]">{l.name.split(" ").map(x=>x[0]).slice(0,2).join("")}</span><div className="min-w-0"><p className="truncate text-sm font-bold text-[#25484c]">{l.name}</p><p className="mt-1 text-xs text-[#758985]">{l.country} · {l.marks ?? "—"}% marks · IELTS {l.ielts}</p></div></div><div className="flex items-center gap-3"><StatusPill tone="warn">{since(l.lastReplyAt)}</StatusPill><button onClick={()=>onNavigate("students")} className="rounded-lg p-2 text-[#6a8582] hover:bg-[#f3f7f3]" aria-label={`Open ${l.name}`}><ArrowRight size={16} /></button></div></div>)}</div> : <EmptyState icon={CheckCircle2} title="No quiet students" text="The reminder check has no overdue quiet leads right now." />}
      </section>
      <section className="rounded-2xl border border-[#dce5df] bg-[#eaf2ec] p-5 sm:p-6"><p className="eyebrow">Office guardrails</p><h3 className="mt-1 font-serif text-2xl">Safe to review.</h3><div className="mt-5 space-y-3">
        <Guardrail icon={ShieldCheck} title="Human approval" copy="Every generated reply waits in the approval queue." />
        <Guardrail icon={BookOpen} title="Office list only" copy="Program answers use the data stored in this database." />
        <Guardrail icon={FileCheck2} title="Document check" copy="Name and expiry checks are visible before staff verification." />
      </div><div className="mt-5 rounded-xl border border-[#d6e5da] bg-white/70 px-4 py-3 text-xs leading-5 text-[#617877]">The assistant does not promise admission, visa approval or fee accuracy. Listed values are for practice.</div>
      </section>
    </div>
    <div className="mt-5 grid gap-5 lg:grid-cols-2">
      <section className="rounded-2xl border border-[#dce5df] bg-white p-5"><div className="flex items-center justify-between"><div><p className="eyebrow">Saved records</p><h3 className="mt-1 font-serif text-xl">Lead stages</h3></div><button onClick={()=>onNavigate("students")} aria-label="Open student records" className="rounded-lg p-2 text-[#6b8682] hover:bg-[#f3f7f3]"><ArrowRight size={16} /></button></div><div className="mt-4 space-y-3">{d.stages.map((s)=><div key={s.label} className="grid grid-cols-[110px_1fr_28px] items-center gap-3 text-sm"><span className="text-[#5c7574]">{s.label}</span><div className="h-2 overflow-hidden rounded-full bg-[#eef2ef]"><div className="h-full rounded-full bg-[#7fad94]" style={{width:`${Math.max(4,d.totalLeads ? s.value/d.totalLeads*100 : 0)}%`}} /></div><strong className="text-right text-[#34575a]">{s.value}</strong></div>)}</div></section>
      <section className="rounded-2xl border border-[#dce5df] bg-white p-5"><div className="flex items-center justify-between"><div><p className="eyebrow">Student destinations</p><h3 className="mt-1 font-serif text-xl">Where they’re considering</h3></div><Globe2 size={18} className="text-[#718d83]" /></div><div className="mt-4 flex flex-wrap gap-2">{d.countries.map((c)=><span key={c.label} className="rounded-xl border border-[#e2eae4] bg-[#f9fbf8] px-3 py-2 text-sm"><strong className="text-[#294d51]">{c.value}</strong><span className="ml-2 text-[#6d8280]">{c.label}</span></span>)}</div><p className="mt-5 text-xs text-[#899893]">{d.deadlinesSoon} listed deadlines fall within the next 14 days.</p></section>
    </div>
  </>;
}

function Guardrail({ icon: Icon, title, copy }: { icon: typeof ShieldCheck; title: string; copy: string }) { return <div className="flex gap-3"><span className="mt-0.5 text-[#517965]"><Icon size={17} /></span><div><p className="text-sm font-bold text-[#2a4e50]">{title}</p><p className="mt-0.5 text-xs leading-5 text-[#718681]">{copy}</p></div></div>; }

function StudentsView({ data, query, setQuery, reload, notice, busy, action }: {
  data: WorkspaceData; query: string; setQuery: (value: string) => void; reload: () => Promise<void>;
  notice: (value: string) => void; busy: boolean; action: (path: string, method: string, body?: unknown, successText?: string) => Promise<void>;
}) {
  const [selected, setSelected] = useState<number | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const filtered = data.leads.filter((l) => `${l.name} ${l.email} ${l.phone} ${l.country}`.toLowerCase().includes(query.toLowerCase()));
  const lead = data.leads.find((l) => l.id === selected) ?? filtered[0] ?? null;
  return <>
    <SectionIntro eyebrow="Lead management" title="Students and enquiries" description="A shared record for every student, their destination, conversation status and recent activity." action={<SolidButton onClick={()=>setShowAdd(!showAdd)}><Plus size={17} /> Add student</SolidButton>} />
    {showAdd && <ManualLeadForm close={()=>setShowAdd(false)} reload={reload} notice={notice} />}
    <div className="grid gap-5 xl:grid-cols-[minmax(0,1.2fr)_minmax(330px,.8fr)]">
      <section className="min-w-0 rounded-2xl border border-[#dce5df] bg-white">
        <div className="flex flex-col gap-3 border-b border-[#edf1ee] p-4 sm:flex-row sm:items-center sm:justify-between"><div><p className="text-sm font-extrabold text-[#2b4f52]">All students <span className="ml-1 font-semibold text-[#8a9a94]">{filtered.length}</span></p><p className="mt-1 text-xs text-[#83938e]">Demo records are labeled for testing.</p></div><label className="relative block sm:w-[250px]"><Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8a9a94]" /><input className="form-control min-h-10 pl-9 text-sm" placeholder="Search name or country" value={query} onChange={(e)=>setQuery(e.target.value)} /></label></div>
        <div className="thin-scrollbar overflow-x-auto"><table className="w-full min-w-[640px] text-left text-sm"><thead className="bg-[#f8faf8] text-xs uppercase tracking-wide text-[#7d908b]"><tr><th className="px-4 py-3 font-bold">Student</th><th className="px-4 py-3 font-bold">Destination</th><th className="px-4 py-3 font-bold">Last reply</th><th className="px-4 py-3 font-bold">Stage</th></tr></thead><tbody className="divide-y divide-[#edf1ee]">{filtered.map((l)=><tr key={l.id} onClick={()=>setSelected(l.id)} className={`cursor-pointer transition hover:bg-[#f8faf8] ${lead?.id===l.id ? "bg-[#f0f6f0]" : ""}`}><td className="px-4 py-3.5"><p className="font-bold text-[#294d51]">{l.name}{l.isDemo===1&&<span className="ml-2 align-middle"><StatusPill tone="neutral">Practice</StatusPill></span>}</p><p className="mt-1 text-xs text-[#81918c]">{l.email}</p></td><td className="px-4 py-3.5"><p className="font-semibold text-[#496665]">{l.country}</p><p className="mt-1 text-xs text-[#81918c]">{l.marks ?? "—"}% · IELTS {l.ielts}</p></td><td className="px-4 py-3.5"><span className={since(l.lastReplyAt).includes("days") ? "font-semibold text-[#926925]" : "text-[#718581]"}>{since(l.lastReplyAt)}</span></td><td className="px-4 py-3.5"><StatusPill tone={l.stage==="Lost"?"bad":l.stage==="Converted"?"good":"dark"}>{l.stage}</StatusPill></td></tr>)}</tbody></table></div>
        {!filtered.length && <EmptyState icon={Users} title="No matching student" text="Try another name, phone number or country." />}
      </section>
      {lead ? <StudentDetails lead={lead} messages={data.messages.filter((m)=>m.leadId===lead.id)} documents={data.documents.filter((d)=>d.leadId===lead.id)} action={action} busy={busy} /> : <EmptyState icon={Users} title="Choose a student" text="Student details appear here." />}
    </div>
  </>;
}

function StudentDetails({ lead, messages, documents, action, busy }: {
  lead: Lead; messages: MessageRow[]; documents: DocumentRow[];
  action: (path: string, method: string, body?: unknown, successText?: string) => Promise<void>; busy: boolean;
}) {
  const [stage, setStage] = useState(lead.stage);
  const [reason, setReason] = useState("");
  const [reasonOpen, setReasonOpen] = useState(false);
  useEffect(()=>setStage(lead.stage),[lead.stage]);
  async function saveStage() {
    if (stage === "Lost" && !reasonOpen) { setReasonOpen(true); return; }
    await action(`/api/staff/leads/${lead.id}`, "PATCH", { stage, reason }, "Student stage updated.");
    setReasonOpen(false);
  }
  return <aside className="min-w-0 rounded-2xl border border-[#dce5df] bg-white p-5 sm:p-6">
    <div className="flex items-start justify-between gap-3"><div className="flex min-w-0 items-center gap-3"><span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-[#e4f0e7] text-lg font-extrabold text-[#376451]">{lead.name.split(" ").map(x=>x[0]).slice(0,2).join("")}</span><div className="min-w-0"><h3 className="truncate font-serif text-2xl">{lead.name}</h3><p className="mt-1 truncate text-xs text-[#718581]">{lead.email}</p></div></div><StatusPill tone="dark">{lead.country}</StatusPill></div>
    <div className="mt-5 grid grid-cols-2 gap-3 rounded-xl bg-[#f6f8f5] p-3 text-sm"><div><p className="text-xs text-[#84938e]">Phone</p><p className="mt-1 font-bold text-[#3b5b5d]">{lead.phone}</p></div><div><p className="text-xs text-[#84938e]">Study profile</p><p className="mt-1 font-bold text-[#3b5b5d]">{lead.marks ?? "—"}% · IELTS {lead.ielts}</p></div><div><p className="text-xs text-[#84938e]">Budget</p><p className="mt-1 font-bold text-[#3b5b5d]">{lead.budget || "Not provided"}</p></div><div><p className="text-xs text-[#84938e]">Last replied</p><p className="mt-1 font-bold text-[#3b5b5d]">{since(lead.lastReplyAt)}</p></div></div>
    <div className="mt-5 flex items-end gap-2"><label className="min-w-0 flex-1"><span className="field-label">Lead stage</span><select className="form-control" value={stage} onChange={(e)=>{setStage(e.target.value);setReasonOpen(e.target.value==="Lost");}}><option>New</option><option>Contacted</option><option>Counselling</option><option>Converted</option><option>Lost</option></select></label><SolidButton onClick={saveStage} disabled={busy}>Update</SolidButton></div>
    {reasonOpen && stage==="Lost" && <label className="mt-3 block"><span className="field-label">Reason for marking Lost</span><input className="form-control" value={reason} onChange={(e)=>setReason(e.target.value)} placeholder="Add a short reason" /></label>}
    <div className="mt-6"><div className="flex items-center justify-between"><h4 className="text-sm font-extrabold text-[#32575a]">Conversation</h4><StatusPill tone="neutral">{messages.length}</StatusPill></div>{messages.length?<div className="mt-3 max-h-56 space-y-2 overflow-y-auto pr-1">{[...messages].sort((a,b)=>new Date(a.createdAt).getTime()-new Date(b.createdAt).getTime()).map((m)=><div key={m.id} className={`rounded-xl p-3 text-sm ${m.sender==="agent"?"bg-[#eff5ef]":"bg-[#f7f8f5]"}`}><div className="flex items-center justify-between gap-2"><span className="text-xs font-extrabold capitalize text-[#55746f]">{m.sender} · {m.kind}</span>{m.sender==="agent"&&<StatusPill tone={m.status==="pending_approval"?"warn":m.status==="rejected"?"bad":"good"}>{m.status.replaceAll("_"," ")}</StatusPill>}</div><p className="mt-2 whitespace-pre-wrap text-xs leading-5 text-[#445f61]">{m.body}</p></div>)}</div>:<p className="mt-3 rounded-xl bg-[#f8faf8] p-3 text-xs text-[#83938e]">No saved messages yet.</p>}</div>
    <div className="mt-5"><div className="flex items-center justify-between"><h4 className="text-sm font-extrabold text-[#32575a]">Documents</h4><span className="text-xs text-[#81918c]">{documents.length} file{documents.length===1?"":"s"}</span></div>{documents.length?<div className="mt-3 space-y-2">{documents.map((d)=><div key={d.id} className="flex items-center justify-between gap-2 rounded-xl border border-[#e7eee8] p-3"><div className="min-w-0"><p className="truncate text-xs font-bold text-[#3b5a5d]">{d.docType}</p><p className="mt-1 truncate text-[11px] text-[#7f918d]">{d.checkNote}</p></div><StatusPill tone={d.reviewStatus==="Verified"?"good":d.checkStatus==="problem"?"bad":"warn"}>{d.reviewStatus}</StatusPill></div>)}</div>:<p className="mt-3 rounded-xl bg-[#f8faf8] p-3 text-xs text-[#83938e]">No uploaded documents.</p>}</div>
  </aside>;
}

function ManualLeadForm({ close, reload, notice }: { close: () => void; reload: () => Promise<void>; notice: (v: string)=>void }) {
  const [form, setForm] = useState({ name:"",email:"",phone:"",country:"UK",marks:"",ielts:"Not taken yet",budget:"",source:"Walk-in",studyLevel:"Bachelor's" });
  const [error,setError]=useState(""); const [busy,setBusy]=useState(false);
  const set=(key:keyof typeof form,value:string)=>setForm((f)=>({...f,[key]:value}));
  async function submit(e:FormEvent){e.preventDefault();setBusy(true);setError("");try{await api("/api/staff/leads",{method:"POST",body:JSON.stringify(form)});await reload();notice("Student added.");close();}catch(x){setError(x instanceof Error?x.message:"Could not add student.");}finally{setBusy(false);}}
  return <form onSubmit={submit} className="mb-5 rounded-2xl border border-[#cdded3] bg-[#f9fcf8] p-5"><div className="flex items-start justify-between"><div><p className="eyebrow">Add a walk-in / social lead</p><h3 className="mt-1 font-serif text-xl">New student details</h3></div><button type="button" onClick={close} aria-label="Close" className="rounded-lg p-2 text-[#718581] hover:bg-white"><X size={17}/></button></div><div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4"><input className="form-control" placeholder="Full name" value={form.name} onChange={(e)=>set("name",e.target.value)} required/><input type="email" className="form-control" placeholder="Email" value={form.email} onChange={(e)=>set("email",e.target.value)} required/><input className="form-control" placeholder="Phone" value={form.phone} onChange={(e)=>set("phone",e.target.value)} required/><select className="form-control" value={form.country} onChange={(e)=>set("country",e.target.value)}>{["UK","Canada","Germany","Australia","New Zealand","Other"].map((x)=><option key={x}>{x}</option>)}</select><input className="form-control" placeholder="Marks %" inputMode="decimal" value={form.marks} onChange={(e)=>set("marks",e.target.value)}/><select className="form-control" value={form.ielts} onChange={(e)=>set("ielts",e.target.value)}>{["Not taken yet","6.0","6.5","7.0","7.5","8.0","8.5","9.0"].map((x)=><option key={x}>{x}</option>)}</select><input className="form-control" placeholder="Budget (optional)" value={form.budget} onChange={(e)=>set("budget",e.target.value)}/><select className="form-control" value={form.source} onChange={(e)=>set("source",e.target.value)}>{["Walk-in","Facebook","WhatsApp"].map((x)=><option key={x}>{x}</option>)}</select></div>{error&&<p role="alert" className="mt-3 text-sm text-[#963e35]">{error}</p>}<div className="mt-4 flex justify-end gap-2"><OutlineButton onClick={close}>Cancel</OutlineButton><SolidButton type="submit" disabled={busy}>{busy?"Saving…":"Save student"}</SolidButton></div></form>;
}

function ProgramsView({ programs, reload, notice, action, isAdmin, busy }: {
  programs: Program[]; reload:()=>Promise<void>; notice:(v:string)=>void;
  action:(path:string,method:string,body?:unknown,successText?:string)=>Promise<void>; isAdmin:boolean; busy:boolean;
}) {
  const [search,setSearch]=useState(""); const [adding,setAdding]=useState(false);
  const rows=programs.filter((p)=>`${p.name} ${p.program} ${p.country}`.toLowerCase().includes(search.toLowerCase()));
  return <>
    <SectionIntro eyebrow="Office knowledge source" title="Universities and programs" description="Agent drafts use only these saved records. Keep example fees and dates clearly marked until the office replaces them with verified details." action={isAdmin?<SolidButton onClick={()=>setAdding(!adding)}><Plus size={17}/> Add program</SolidButton>:undefined}/>
    {adding&&<ProgramForm close={()=>setAdding(false)} reload={reload} notice={notice}/>}
    <label className="relative mb-4 block max-w-md"><Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8a9a94]"/><input className="form-control pl-9" placeholder="Search country, university or program" value={search} onChange={(e)=>setSearch(e.target.value)}/></label>
    <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{rows.map((p)=><ProgramCard key={p.id} program={p}/>)}</div>
    {!rows.length&&<EmptyState icon={GraduationCap} title="No programs match" text="Try a different search."/>}
  </>;
}

function ProgramForm({close,reload,notice}:{close:()=>void;reload:()=>Promise<void>;notice:(v:string)=>void}){
  const [form,setForm]=useState({name:"",country:"UK",program:"",annualFee:"",deadline:"",minMarks:"70",minIelts:"6.5",documentsNeeded:"Passport, transcript, IELTS"});
  const [error,setError]=useState("");const [busy,setBusy]=useState(false);const set=(k:keyof typeof form,v:string)=>setForm(f=>({...f,[k]:v}));
  async function submit(e:FormEvent){e.preventDefault();setBusy(true);setError("");try{await api("/api/staff/programs",{method:"POST",body:JSON.stringify({...form,minMarks:Number(form.minMarks),minIelts:Number(form.minIelts)})});await reload();notice("Program added to the office list.");close();}catch(x){setError(x instanceof Error?x.message:"Program could not be saved.");}finally{setBusy(false);}}
  return <form onSubmit={submit} className="mb-5 rounded-2xl border border-[#cdded3] bg-[#f9fcf8] p-5"><div className="flex items-start justify-between"><div><p className="eyebrow">Admin only</p><h3 className="mt-1 font-serif text-xl">Add an office program</h3></div><button type="button" onClick={close} aria-label="Close" className="rounded-lg p-2 text-[#718581] hover:bg-white"><X size={17}/></button></div><div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4"><input className="form-control" placeholder="University name" value={form.name} onChange={e=>set("name",e.target.value)} required/><input className="form-control" placeholder="Country" value={form.country} onChange={e=>set("country",e.target.value)} required/><input className="form-control" placeholder="Program name" value={form.program} onChange={e=>set("program",e.target.value)} required/><input className="form-control" placeholder="Annual fee" value={form.annualFee} onChange={e=>set("annualFee",e.target.value)} required/><label className="block"><span className="field-label">Deadline</span><input type="date" className="form-control" value={form.deadline} onChange={e=>set("deadline",e.target.value)} required/></label><label className="block"><span className="field-label">Minimum marks</span><input type="number" min="0" max="100" className="form-control" value={form.minMarks} onChange={e=>set("minMarks",e.target.value)} required/></label><label className="block"><span className="field-label">Minimum IELTS</span><input type="number" step="0.5" min="0" max="9" className="form-control" value={form.minIelts} onChange={e=>set("minIelts",e.target.value)} required/></label><input className="form-control" placeholder="Documents needed" value={form.documentsNeeded} onChange={e=>set("documentsNeeded",e.target.value)} required/></div>{error&&<p role="alert" className="mt-3 text-sm text-[#963e35]">{error}</p>}<div className="mt-4 flex justify-end gap-2"><OutlineButton onClick={close}>Cancel</OutlineButton><SolidButton type="submit" disabled={busy}>{busy?"Saving…":"Save program"}</SolidButton></div></form>;
}

function DocumentsView({ documents, action, busy }: { documents:DocumentRow[]; action:(path:string,method:string,body?:unknown,successText?:string)=>Promise<void>; busy:boolean }) {
  const [reasonId,setReasonId]=useState<number|null>(null);const [reason,setReason]=useState("");
  async function reject(id:number){if(reason.length<5)return;await action(`/api/staff/documents/${id}`,"PATCH",{action:"reject",reason},"Document rejection saved.");setReasonId(null);setReason("");}
  return <>
    <SectionIntro eyebrow="Document review" title="Check before you verify" description="Automated checks flag a name mismatch or expired passport. A staff member must verify or reject each upload." action={<span className="inline-flex items-center gap-2 rounded-xl bg-[#fff2d7] px-3 py-2 text-xs font-bold text-[#805e28]"><CircleAlert size={15}/> Field check only · no OCR</span>}/>
    <div className="mb-5 rounded-2xl border border-[#eadcb9] bg-[#fff8e8] p-4 text-sm leading-6 text-[#765d32]">For a student upload, the student enters the name, expiry date or IELTS score printed on the file. The system checks those entered fields; it does not read text from the PDF or image. Staff still reviews the original file.</div>
    <div className="grid gap-4 lg:grid-cols-2">{documents.map((d)=><article key={d.id} className="rounded-2xl border border-[#dce5df] bg-white p-5">
      <div className="flex items-start justify-between gap-3"><div className="flex min-w-0 gap-3"><span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#e8f0e9] text-[#57775f]"><FileText size={18}/></span><div className="min-w-0"><h3 className="truncate text-sm font-extrabold text-[#294d51]">{d.docType} · {d.studentName}</h3><p className="mt-1 truncate text-xs text-[#80918c]">{d.fileName}{d.isDemo===1?" · practice file":""}</p></div></div><StatusPill tone={d.reviewStatus==="Verified"?"good":d.reviewStatus==="Rejected"||d.checkStatus==="problem"?"bad":"warn"}>{d.reviewStatus}</StatusPill></div>
      <div className={`mt-4 rounded-xl px-3.5 py-3 text-sm leading-5 ${d.checkStatus==="problem"?"bg-[#fff0ed] text-[#904940]":"bg-[#eff6f0] text-[#426b52]"}`}><strong>{d.checkStatus==="problem"?"Problem found":"Automated check"}:</strong> {d.checkNote}</div>
      {d.rejectionReason&&<p className="mt-3 text-xs leading-5 text-[#93443a]">Staff reason: {d.rejectionReason}</p>}
      <div className="mt-4 flex flex-wrap items-center justify-between gap-2"><span className="text-xs text-[#879690]">Added {dateLabel(d.createdAt)}</span><div className="flex gap-2">{d.demoPath?<a href={d.demoPath} target="_blank" rel="noreferrer" className="inline-flex min-h-10 items-center gap-2 rounded-xl border border-[#d8e3dd] px-3 text-xs font-bold text-[#476766] hover:bg-[#f7faf7]">Open sample <ArrowUpRight size={14}/></a>:<a href={`/api/files/${d.id}`} target="_blank" rel="noreferrer" className="inline-flex min-h-10 items-center gap-2 rounded-xl border border-[#d8e3dd] px-3 text-xs font-bold text-[#476766] hover:bg-[#f7faf7]">Open file <ArrowUpRight size={14}/></a>}{d.reviewStatus==="Pending review"&&<><OutlineButton disabled={busy||d.checkStatus==="problem"} onClick={()=>action(`/api/staff/documents/${d.id}`,"PATCH",{action:"verify"},"Document verified.")}><Check size={15}/>{d.checkStatus==="problem"?"Resolve issue":"Verify"}</OutlineButton><button disabled={busy} onClick={()=>{setReasonId(reasonId===d.id?null:d.id);setReason("");}} className="min-h-10 rounded-xl border border-[#efd7d1] px-3 text-xs font-bold text-[#9a4b40] hover:bg-[#fff5f2]">Reject</button></>}</div></div>
      {reasonId===d.id&&<div className="mt-3 flex flex-col gap-2 rounded-xl bg-[#fff7f4] p-3 sm:flex-row"><input className="form-control min-h-10" placeholder="Reason the student can act on" value={reason} onChange={e=>setReason(e.target.value)}/><button disabled={busy||reason.trim().length<5} onClick={()=>reject(d.id)} className="min-h-10 shrink-0 rounded-xl bg-[#8f483e] px-3 text-xs font-bold text-white disabled:opacity-50">Save rejection</button></div>}
    </article>)}</div>
    {!documents.length&&<EmptyState icon={FileCheck2} title="No documents yet" text="Student uploads and the fictional practice files will appear here."/>}
  </>;
}

function FollowupsView({ rows, action, busy, reload, notice }: { rows:FollowUp[]; action:(path:string,method:string,body?:unknown,successText?:string)=>Promise<void>; busy:boolean; reload:()=>Promise<void>; notice:(v:string)=>void }) {
  const [scanBusy,setScanBusy]=useState(false);
  async function scan(){setScanBusy(true);try{const result=await api<{draftsCreated:number;quietStudents:number;notice:string}>("/api/staff/followups/scan",{method:"POST",body:"{}"});await reload();notice(`${result.notice} ${result.draftsCreated} new draft(s).`);}catch(e){notice(e instanceof Error?e.message:"Reminder scan failed.");}finally{setScanBusy(false);}}
  const open=rows.filter(r=>r.status==="Open");
  return <>
    <SectionIntro eyebrow="Reminder desk" title="Follow-ups, kept visible" description="The scan finds students quiet for 3+ days and programs with a deadline in the next 14 days. It creates drafts only; staff still approves each message." action={<SolidButton onClick={scan} disabled={scanBusy}><Bell size={16}/>{scanBusy?"Checking students…":"Scan for reminders"}</SolidButton>}/>
    <div className="mb-5 rounded-2xl border border-[#dce5df] bg-[#eaf2ec] p-4 text-sm leading-6 text-[#56716e]">Run the reminder scan each day. It checks saved student replies and the office deadline list. No message leaves the office automatically.</div>
    <div className="overflow-hidden rounded-2xl border border-[#dce5df] bg-white"><div className="flex items-center justify-between border-b border-[#edf1ee] px-4 py-4"><div><p className="text-sm font-extrabold text-[#315459]">Follow-up tasks</p><p className="mt-1 text-xs text-[#84938e]">{open.length} open · {rows.length-open.length} completed</p></div><Clock3 size={18} className="text-[#82948d]"/></div>{rows.length?<div className="divide-y divide-[#edf1ee]">{rows.map((r)=><div key={r.id} className="flex flex-wrap items-center justify-between gap-3 px-4 py-4 sm:px-5"><div className="flex min-w-0 items-start gap-3"><span className={`mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-xl ${r.status==="Open"?"bg-[#fff2d7] text-[#8a642c]":"bg-[#e6f2e9] text-[#397254]"}`}><Bell size={16}/></span><div className="min-w-0"><p className="text-sm font-bold text-[#315357]">{r.studentName} · {r.title}</p><p className="mt-1 text-xs text-[#7e8f8a]">{r.country} · last reply {since(r.lastReplyAt)} · due {dateLabel(r.dueAt)}</p></div></div><div className="flex items-center gap-2"><StatusPill tone={r.status==="Open"?"warn":"good"}>{r.status}</StatusPill>{r.status==="Open"&&<OutlineButton disabled={busy} onClick={()=>action(`/api/staff/followups/${r.id}`,"PATCH",{status:"Completed"},"Follow-up completed.")}>Mark done</OutlineButton>}</div></div>)}</div>:<EmptyState icon={Clock3} title="No follow-ups yet" text="Run a scan to create a reminder draft for quiet students."/>}</div>
  </>;
}

function ApprovalsView({ messages, action, busy }: { messages:MessageRow[]; action:(path:string,method:string,body?:unknown,successText?:string)=>Promise<void>; busy:boolean }) {
  const [filter,setFilter]=useState("pending_approval");
  const rows=messages.filter(m=>m.sender==="agent"&&(filter==="all"||m.status===filter));
  return <>
    <SectionIntro eyebrow="Human review" title="Approve before sharing" description="Every message below was drafted from the office list or a quiet-student rule. Approving makes it visible in that student’s private portal." action={<select className="form-control min-h-10 sm:w-[190px]" value={filter} onChange={e=>setFilter(e.target.value)}><option value="pending_approval">Needs review</option><option value="approved">Approved</option><option value="sent">Sent by email</option><option value="rejected">Rejected</option><option value="all">All drafts</option></select>}/>
    <div className="mb-5 rounded-2xl border border-[#cfe2d4] bg-[#eef6ef] p-4 text-sm leading-6 text-[#4e6c5a]"><strong>Approval rule:</strong> a draft stays private to staff until you approve it. Email delivery is not configured, so approved replies appear in the student’s private portal and are not reported as emailed.</div>
    <div className="space-y-4">{rows.map(m=><article key={m.id} className="rounded-2xl border border-[#dce5df] bg-white p-5 sm:p-6"><div className="flex flex-wrap items-start justify-between gap-3"><div><div className="flex flex-wrap items-center gap-2"><h3 className="font-serif text-xl">{m.studentName}</h3><StatusPill tone={m.kind==="followup"?"warn":"dark"}>{m.kind==="followup"?"Follow-up":"Reply"}</StatusPill></div><p className="mt-1 text-xs text-[#80918c]">{m.country} · {m.email} · drafted {dateLabel(m.createdAt)}</p></div><StatusPill tone={m.status==="pending_approval"?"warn":m.status==="rejected"?"bad":m.status==="sent"?"good":"dark"}>{m.status.replaceAll("_"," ")}</StatusPill></div><div className="mt-4 whitespace-pre-wrap rounded-2xl bg-[#f7f9f6] p-4 text-sm leading-6 text-[#496365]">{m.body}</div>{m.approvedBy&&<p className="mt-3 text-xs text-[#778b85]">Approved by {m.approvedBy} · {dateLabel(m.approvedAt)}</p>}{m.status==="pending_approval"&&<div className="mt-4 flex flex-wrap justify-end gap-2"><button disabled={busy} onClick={()=>action(`/api/staff/messages/${m.id}`,"PATCH",{action:"reject",reason:"Staff declined this draft."},"Draft rejected; it remains visible in the audit record.")} className="inline-flex min-h-10 items-center gap-2 rounded-xl border border-[#efd7d1] px-3.5 text-sm font-bold text-[#964a40] hover:bg-[#fff6f3]">Reject draft</button><SolidButton disabled={busy} onClick={()=>action(`/api/staff/messages/${m.id}`,"PATCH",{action:"approve"},"Approved. It is now visible in the student portal.")}><Check size={16}/> Approve for student portal</SolidButton></div>}</article>)}
      {!rows.length&&<EmptyState icon={MailCheck} title={filter==="pending_approval"?"No drafts waiting":"No messages in this filter"} text={filter==="pending_approval"?"Student questions and reminder drafts will wait here for a staff decision.":"Choose another status to see drafts."}/>}</div>
  </>;
}

function DatabaseView() {
  const [table,setTable]=useState("leads");const [rows,setRows]=useState<Record<string,unknown>[]>([]);const [columns,setColumns]=useState<string[]>([]);const [busy,setBusy]=useState(false);const [error,setError]=useState("");
  const tables=["leads","universities","documents","messages","followups","audit_log"];
  useEffect(()=>{let active=true;setBusy(true);setError("");api<{columns:string[];rows:Record<string,unknown>[]}>(`/api/staff/database?table=${encodeURIComponent(table)}`).then(data=>{if(active){setRows(data.rows);setColumns(data.columns);}}).catch(e=>{if(active)setError(e instanceof Error?e.message:"Database records could not load.");}).finally(()=>{if(active)setBusy(false);});return()=>{active=false;};},[table]);
  return <>
    <SectionIntro eyebrow="Live data view" title="Database records" description="A read-only view of the saved office tables. Changes made in the workspace persist in the database and appear here after refresh." action={<select aria-label="Choose database table" className="form-control min-h-10 sm:w-[190px]" value={table} onChange={e=>setTable(e.target.value)}>{tables.map(t=><option key={t}>{t}</option>)}</select>}/>
    <div className="overflow-hidden rounded-2xl border border-[#dce5df] bg-white"><div className="flex items-center justify-between border-b border-[#edf1ee] px-4 py-4"><div><p className="text-sm font-extrabold text-[#315459]">{table}</p><p className="mt-1 text-xs text-[#82928d]">{rows.length} row{rows.length===1?"":"s"} shown · read-only</p></div><Database size={18} className="text-[#82948d]"/></div>{error&&<p role="alert" className="m-4 rounded-xl bg-[#fff0ed] p-3 text-sm text-[#963e35]">{error}</p>}{busy?<p className="p-6 text-sm text-[#758985]">Reading database…</p>:rows.length?<div className="thin-scrollbar overflow-x-auto"><table className="w-full min-w-[900px] text-left text-xs"><thead className="bg-[#f8faf8] text-[11px] uppercase tracking-wide text-[#728681]"><tr>{columns.map(c=><th key={c} className="whitespace-nowrap px-3 py-3 font-bold">{c}</th>)}</tr></thead><tbody className="divide-y divide-[#edf1ee]">{rows.map((row,i)=><tr key={i} className="align-top">{columns.map(c=><td key={c} className="max-w-[280px] px-3 py-3 text-[#496365]"><span className="line-clamp-3 whitespace-pre-wrap">{String(row[c]??"—")}</span></td>)}</tr>)}</tbody></table></div>:!error&&<EmptyState icon={Database} title="Table is empty" text="Records will appear here after a student or staff member saves them."/>}</div>
  </>;
}

function TeamView(){
  const [members,setMembers]=useState<{id:number;email:string;role:string;active:number;createdAt:string}[]>([]);
  const [email,setEmail]=useState("");const [busy,setBusy]=useState(false);const [error,setError]=useState("");const [notice,setNotice]=useState("");
  const load=useCallback(async()=>{const rows=await api<{id:number;email:string;role:string;active:number;createdAt:string}[]>("/api/staff/team");setMembers(rows);},[]);
  useEffect(()=>{void load().catch(e=>setError(e instanceof Error?e.message:"Staff list could not load."));},[load]);
  async function add(event:FormEvent){event.preventDefault();setBusy(true);setError("");setNotice("");try{await api("/api/staff/team",{method:"POST",body:JSON.stringify({email,role:"staff"})});setEmail("");await load();setNotice("Staff email added. They can sign in with the matching ChatGPT account.");}catch(e){setError(e instanceof Error?e.message:"Staff member could not be added.");}finally{setBusy(false);}}
  async function toggle(member:{id:number;email:string;role:string;active:number}){setBusy(true);setError("");try{await api(`/api/staff/team/${member.id}`,{method:"PATCH",body:JSON.stringify({active:!member.active,role:member.role})});await load();setNotice("Staff access updated.");}catch(e){setError(e instanceof Error?e.message:"Staff access could not be changed.");}finally{setBusy(false);}}
  return <>
    <SectionIntro eyebrow="Admin only" title="Staff access" description="Add the email address each staff member uses to sign in. They must use the same ChatGPT account email to open office records." />
    <div className="grid gap-5 xl:grid-cols-[.8fr_1.2fr]">
      <form onSubmit={add} className="h-fit rounded-2xl border border-[#dce5df] bg-white p-5"><p className="eyebrow">Add a team member</p><h3 className="mt-1 font-serif text-2xl">Grant office access</h3><p className="mt-2 text-sm leading-6 text-[#718581]">This records staff access in the database. It does not send an invitation or share a password.</p><label className="mt-5 block"><span className="field-label">Staff sign-in email</span><input type="email" className="form-control" value={email} onChange={e=>setEmail(e.target.value)} required placeholder="staff@example.com" /></label>{error&&<p role="alert" className="mt-3 text-sm text-[#963e35]">{error}</p>}{notice&&<p role="status" className="mt-3 rounded-xl bg-[#eef6ef] p-3 text-sm text-[#426b52]">{notice}</p>}<SolidButton type="submit" disabled={busy} className="mt-4 w-full"><Plus size={16}/>{busy?"Saving…":"Add staff member"}</SolidButton><p className="mt-4 text-xs leading-5 text-[#82918d]">Only the admin can add or deactivate staff. Keep at least one active admin.</p></form>
      <section className="overflow-hidden rounded-2xl border border-[#dce5df] bg-white"><div className="flex items-center justify-between border-b border-[#edf1ee] p-4"><div><p className="text-sm font-extrabold text-[#315459]">Office staff</p><p className="mt-1 text-xs text-[#82928d]">{members.filter(m=>m.active).length} active</p></div><ShieldCheck size={18} className="text-[#648675]"/></div>{members.length?<div className="divide-y divide-[#edf1ee]">{members.map(member=><div key={member.id} className="flex flex-wrap items-center justify-between gap-3 px-4 py-4"><div className="flex min-w-0 items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-full bg-[#e8f0e9] text-sm font-extrabold text-[#456d58]">{member.email.slice(0,1).toUpperCase()}</span><div className="min-w-0"><p className="truncate text-sm font-bold text-[#315357]">{member.email}</p><p className="mt-1 text-xs capitalize text-[#84938e]">{member.role} · added {dateLabel(member.createdAt)}</p></div></div><div className="flex items-center gap-2"><StatusPill tone={member.active?"good":"bad"}>{member.active?"Active":"Inactive"}</StatusPill><OutlineButton disabled={busy||(member.role==="admin"&&member.active===1)} onClick={()=>toggle(member)}>{member.active?"Deactivate":"Reactivate"}</OutlineButton></div></div>)}</div>:<EmptyState icon={Users} title="No staff records" text="The first admin appears here after setup."/>}</section>
    </div>
  </>;
}

function EmptyState({ icon:Icon,title,text }: { icon:typeof CheckCircle2; title:string; text:string }){return <div className="grid min-h-[180px] place-items-center p-6 text-center"><div><span className="mx-auto grid h-11 w-11 place-items-center rounded-2xl bg-[#eff4ef] text-[#668278]"><Icon size={19}/></span><h3 className="mt-3 text-sm font-extrabold text-[#3c5c5e]">{title}</h3><p className="mx-auto mt-1 max-w-sm text-xs leading-5 text-[#84938e]">{text}</p></div></div>;}
