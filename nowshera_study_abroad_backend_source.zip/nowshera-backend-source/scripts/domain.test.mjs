import test from "node:test";
import assert from "node:assert/strict";
import {
  checkDocument,
  draftCatalogReply,
  isQuiet,
  normalizePhone,
  validateInquiry,
} from "../lib/domain.js";

test("inquiry normalization catches equivalent Pakistan phone formats", () => {
  assert.equal(normalizePhone("+92 301 2345678"), "03012345678");
  const result = validateInquiry({
    name: "Ali Khan",
    email: " Ali@Example.Test ",
    phone: "+92 301 2345678",
    country: "UK",
    marks: "78%",
    ielts: "6.5",
  });
  assert.equal(result.valid, true);
  assert.equal(result.value.email, "ali@example.test");
  assert.equal(result.value.phone, "03012345678");
});

test("document checks flag an expired passport and a transcript name mismatch", () => {
  assert.equal(checkDocument({ studentName: "Ali Khan", documentName: "Ali Khan", docType: "Passport", expiresOn: "2030-03-10", today: "2026-09-26" }).status, "ok");
  assert.match(checkDocument({ studentName: "Ali Khan", documentName: "Ali Khan", docType: "Passport", expiresOn: "2025-01-01", today: "2026-09-26" }).note, /expired/i);
  assert.match(checkDocument({ studentName: "Ali Khan", documentName: "Ali Ahmed", docType: "Transcript", today: "2026-09-26" }).note, /does not match/i);
  assert.equal(checkDocument({ studentName: "Ayesha Noor", documentName: "Ayesha Noor", docType: "IELTS result", overallScore: 7, today: "2026-09-26" }).status, "ok");
});

test("catalog answer cites only a matched office record and keeps the approval gate", () => {
  const programs = [{ id: 7, name: "University of Manchester", country: "UK", program: "BSc Computer Science", annualFee: "£32,000", deadline: "2027-01-15", minMarks: 75, minIelts: 6.5, documentsNeeded: "Passport, transcript, IELTS" }];
  const result = draftCatalogReply("What IELTS and fee for University of Manchester?", { country: "UK", marks: 78, ielts: "6.5" }, programs);
  assert.match(result.body, /£32,000/);
  assert.match(result.body, /IELTS/);
  assert.match(result.body, /counselor must approve/i);
  assert.equal(result.sourceProgramId, 7);
  assert.match(draftCatalogReply("Will I definitely get a visa?", { country: "UK" }, []).body, /couldn't (find|confirm)/i);
  const profile = draftCatalogReply("Which programs fit me?", { country: "UK", marks: 69, ielts: "Not taken yet" }, programs);
  assert.match(profile.body, /below at least one listed minimum/i);
  assert.match(draftCatalogReply("Will I definitely get a visa?", { country: "UK" }, programs).body, /couldn't confirm that/i);
});

test("quiet-student rule matches the supplied four-day-old lead", () => {
  const now = Date.parse("2026-09-26T12:00:00.000Z");
  assert.equal(isQuiet("2026-09-22T12:00:00.000Z", now), true);
  assert.equal(isQuiet("2026-09-26T11:00:00.000Z", now), false);
});
