from pathlib import Path
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

OUT = Path(__file__).resolve().parents[1] / "public" / "demo-docs"
OUT.mkdir(parents=True, exist_ok=True)

samples = [
    ("passport-a.pdf", "PASSPORT SAMPLE A", "Ali Khan", [
        ("Document number", "DEMO-ALI-001"),
        ("Date of birth", "14 May 2005"),
        ("Expiry date", "10 Mar 2030"),
        ("Practice result", "OK - name matches and document is in date"),
    ]),
    ("passport-b.pdf", "PASSPORT SAMPLE B", "Ali Khan", [
        ("Document number", "DEMO-ALI-002"),
        ("Date of birth", "14 May 2005"),
        ("Expiry date", "01 Jan 2025"),
        ("Practice result", "PROBLEM - document expired"),
    ]),
    ("transcript.pdf", "TRANSCRIPT SAMPLE", "Ali Ahmed", [
        ("Record number", "DEMO-TR-078"),
        ("Program", "Intermediate Computer Science"),
        ("Marks", "78%"),
        ("Practice result", "PROBLEM - name differs from Ali Khan"),
    ]),
    ("ielts.pdf", "IELTS RESULT SAMPLE", "Ayesha Noor", [
        ("Candidate number", "DEMO-AY-070"),
        ("Test date", "20 Aug 2026"),
        ("Overall score", "7.0"),
        ("Practice result", "OK - name and score format check"),
    ]),
]

for filename, heading, name, fields in samples:
    pdf = canvas.Canvas(str(OUT / filename), pagesize=A4)
    width, height = A4
    pdf.setFillColor(colors.HexColor("#122C36"))
    pdf.rect(0, height - 145, width, 145, fill=1, stroke=0)
    pdf.setFillColor(colors.HexColor("#BFE8DE"))
    pdf.setFont("Helvetica-Bold", 12)
    pdf.drawString(48, height - 48, "NOWSHERA STUDY ABROAD CONSULTANTS")
    pdf.setFillColor(colors.white)
    pdf.setFont("Helvetica-Bold", 22)
    pdf.drawString(48, height - 88, heading)
    pdf.setFont("Helvetica", 11)
    pdf.drawString(48, height - 113, "TRAINING FILE - ALL PEOPLE AND DETAILS ARE FICTIONAL")

    pdf.saveState()
    pdf.translate(width / 2, height / 2)
    pdf.rotate(34)
    pdf.setFillColor(colors.HexColor("#F7E5E2"))
    pdf.setFont("Helvetica-Bold", 33)
    pdf.drawCentredString(0, 0, "DEMO ONLY - NOT VALID ID")
    pdf.restoreState()

    y = height - 205
    pdf.setFillColor(colors.HexColor("#294C56"))
    pdf.setFont("Helvetica-Bold", 11)
    pdf.drawString(52, y, "NAME SHOWN ON DOCUMENT")
    pdf.setFillColor(colors.HexColor("#111827"))
    pdf.setFont("Helvetica-Bold", 19)
    pdf.drawString(52, y - 31, name)
    y -= 86
    for label, value in fields:
        pdf.setStrokeColor(colors.HexColor("#DCE5E7"))
        pdf.line(50, y - 9, width - 50, y - 9)
        pdf.setFillColor(colors.HexColor("#64748B"))
        pdf.setFont("Helvetica-Bold", 10)
        pdf.drawString(52, y + 8, label.upper())
        pdf.setFillColor(colors.HexColor("#172C34"))
        pdf.setFont("Helvetica", 14)
        pdf.drawString(52, y - 7, value)
        y -= 63

    pdf.setFillColor(colors.HexColor("#A43129"))
    pdf.roundRect(48, 52, width - 96, 43, 9, fill=1, stroke=0)
    pdf.setFillColor(colors.white)
    pdf.setFont("Helvetica-Bold", 12)
    pdf.drawCentredString(width / 2, 68, "FICTIONAL PRACTICE DOCUMENT - NEVER USE AS IDENTIFICATION")
    pdf.setFillColor(colors.HexColor("#64748B"))
    pdf.setFont("Helvetica", 9)
    pdf.drawCentredString(width / 2, 32, "Created solely for software testing. No official marks, seals, or real personal records.")
    pdf.save()

print(f"Created {len(samples)} fictional PDFs in {OUT}")
