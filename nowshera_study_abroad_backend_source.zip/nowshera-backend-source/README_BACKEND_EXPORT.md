# Nowshera Study Abroad CRM — backend source bundle

This bundle includes the complete website source because its API routes and browser interface share one Cloudflare Worker application.

## Backend files

- app/api/ — public inquiry, student portal, document upload, staff dashboard, approval, follow-up, and database endpoints.
- db/schema.ts and drizzle/ — D1 schema and migration.
- lib/server.ts — authentication, database bootstrap, sample-data setup, and request helpers.
- lib/domain.js and lib/seed-data.ts — catalog-only reply drafts, document checks, reminder rules, and sample programs.
- scripts/domain.test.mjs — rule tests.

## Runtime

The deployed app uses a Cloudflare Worker-compatible Vinext runtime, D1 (DB) and R2 (BUCKET). This is the source for the deployed version. It is not a separate FastAPI/Supabase or n8n service.

No secret keys or real student documents are included. .env.example contains placeholders only. The demo PDFs in public/demo-docs/ are fictional and watermarked.

## Local checks

With Node.js 22+ and pnpm installed:

1. pnpm install
2. pnpm test
3. pnpm exec tsc --noEmit
4. pnpm run build

The hosted staff setup code and any optional email-provider keys are configured as runtime secrets and are intentionally not included here.
