CREATE TABLE `audit_log` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`actor_user_id` text NOT NULL,
	`actor_email` text NOT NULL,
	`action` text NOT NULL,
	`entity_type` text NOT NULL,
	`entity_id` text NOT NULL,
	`details` text DEFAULT '{}' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_audit_entity_created` ON `audit_log` (`entity_type`,`entity_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `documents` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`lead_id` integer NOT NULL,
	`doc_type` text NOT NULL,
	`file_name` text NOT NULL,
	`mime_type` text NOT NULL,
	`r2_key` text,
	`demo_path` text,
	`name_on_document` text NOT NULL,
	`expires_on` text,
	`overall_score` real,
	`check_status` text NOT NULL,
	`check_note` text NOT NULL,
	`review_status` text DEFAULT 'Pending review' NOT NULL,
	`rejection_reason` text,
	`is_demo` integer DEFAULT 0 NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`lead_id`) REFERENCES `leads`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_documents_lead_created` ON `documents` (`lead_id`,`created_at`);--> statement-breakpoint
CREATE INDEX `idx_documents_review_status` ON `documents` (`review_status`);--> statement-breakpoint
CREATE TABLE `followups` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`lead_id` integer NOT NULL,
	`title` text NOT NULL,
	`due_at` text NOT NULL,
	`status` text DEFAULT 'Open' NOT NULL,
	`created_by` text NOT NULL,
	`reminder_message_id` integer,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`lead_id`) REFERENCES `leads`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`reminder_message_id`) REFERENCES `messages`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE INDEX `idx_followups_status_due` ON `followups` (`status`,`due_at`);--> statement-breakpoint
CREATE UNIQUE INDEX `uq_followup_reminder_once` ON `followups` (`lead_id`,`title`,`due_at`);--> statement-breakpoint
CREATE TABLE `leads` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`name` text NOT NULL,
	`email` text NOT NULL,
	`email_norm` text NOT NULL,
	`phone` text NOT NULL,
	`phone_norm` text NOT NULL,
	`country` text NOT NULL,
	`marks` real,
	`ielts` text NOT NULL,
	`budget` text,
	`study_level` text DEFAULT 'Bachelor''s' NOT NULL,
	`source` text DEFAULT 'Website' NOT NULL,
	`stage` text DEFAULT 'New' NOT NULL,
	`last_reply_at` text NOT NULL,
	`portal_token_hash` text,
	`is_demo` integer DEFAULT 0 NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `uq_leads_email_norm` ON `leads` (`email_norm`);--> statement-breakpoint
CREATE UNIQUE INDEX `uq_leads_phone_norm` ON `leads` (`phone_norm`);--> statement-breakpoint
CREATE INDEX `idx_leads_stage_last_reply` ON `leads` (`stage`,`last_reply_at`);--> statement-breakpoint
CREATE TABLE `messages` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`lead_id` integer NOT NULL,
	`sender` text NOT NULL,
	`body` text NOT NULL,
	`status` text DEFAULT 'received' NOT NULL,
	`kind` text DEFAULT 'conversation' NOT NULL,
	`source_program_id` integer,
	`approved_by` text,
	`approved_at` text,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`lead_id`) REFERENCES `leads`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`source_program_id`) REFERENCES `universities`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE INDEX `idx_messages_lead_created` ON `messages` (`lead_id`,`created_at`);--> statement-breakpoint
CREATE INDEX `idx_messages_status_created` ON `messages` (`status`,`created_at`);--> statement-breakpoint
CREATE TABLE `rate_limits` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`fingerprint` text NOT NULL,
	`requested_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_rate_limits_fingerprint_time` ON `rate_limits` (`fingerprint`,`requested_at`);--> statement-breakpoint
CREATE TABLE `staff_users` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`auth_user_id` text,
	`email` text NOT NULL,
	`role` text DEFAULT 'staff' NOT NULL,
	`active` integer DEFAULT 1 NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `uq_staff_auth_user_id` ON `staff_users` (`auth_user_id`);--> statement-breakpoint
CREATE UNIQUE INDEX `uq_staff_email` ON `staff_users` (`email`);--> statement-breakpoint
CREATE TABLE `universities` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`name` text NOT NULL,
	`country` text NOT NULL,
	`program` text NOT NULL,
	`annual_fee` text NOT NULL,
	`deadline` text NOT NULL,
	`min_marks` real NOT NULL,
	`min_ielts` real NOT NULL,
	`documents_needed` text NOT NULL,
	`active` integer DEFAULT 1 NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `uq_university_program` ON `universities` (`name`,`program`);--> statement-breakpoint
CREATE INDEX `idx_universities_country` ON `universities` (`country`);