# Nowshera Study Abroad CRM

A hosted inquiry and review workspace for Nowshera Study Abroad Consultants. Students can share their profile, view the office's sample program list, use a private portal, and upload fictional practice documents. Staff can see leads, review documents, run follow-up scans, inspect the saved database, and approve every assistant draft before it becomes visible to a student.

## Current implementation

- **Web app and API:** React/TypeScript pages and server routes running on the Sites Worker runtime.
- **Database:** Cloudflare D1 (SQLite) with versioned Drizzle migrations.
- **Private uploads:** Cloudflare R2. Files are served only through an authorized staff request or the student's private portal token.
- **Staff sign-in:** Sign in with ChatGPT. The first office admin uses a one-time setup code; the admin can add staff emails afterward. Staff must use the same ChatGPT account email.
- **Student access:** A high-entropy private portal token is returned after an inquiry. Only a hash of that token is stored in D1.
- **Approvals:** Assistant replies and reminder messages remain staff-only until an authorized staff member approves them. Approved text becomes visible in the student's portal. No email is sent unless a provider has been configured and a staff member separately sends the already-approved message.

This hosted edition uses D1/R2 and Sites authentication so the app can run in the browser without a separately supplied Supabase or hosting account. It does not expose database credentials or setup codes to the browser.

## Seed data

On the first page request after the D1 migration is applied, the app inserts 15 practice programs across the UK, Canada, Germany, Australia and New Zealand, plus the three test students Ali Khan, Ayesha Noor and Hamza Iqbal. It adds the four requested document-check examples. Records are marked as practice data. Sample PDFs are in `public/demo-docs/` and have a clear fictional watermark.

The practice fees and deadlines are not live university information. Replace them with office-verified data before relying on them for real applications.

## Run the checks

Requirements: Node.js 22.13 or newer and pnpm.

```sh
pnpm install
pnpm run db:generate
pnpm test
pnpm run build
```

For a local Worker preview with D1 and R2 bindings:

```sh
pnpm run build
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_aspiring_harrier.sql
pnpm run start
```

If the migration filename has changed, use the current first unapplied SQL file from `drizzle/`. Do not replay a migration already applied to the local D1 database.

## Publish and configure the first admin

The Site workflow publishes the Worker, applies D1 migrations, and wires the D1/R2 resources declared in `.openai/hosting.json`. The public student inquiry form and catalog are intentionally reachable without a staff account. Staff routes require a ChatGPT identity plus an active row in `staff_users`.

1. Set a strong one-time `STAFF_SETUP_CODE` in the site's secret environment settings.
2. Open the site, choose **Staff sign in**, sign in with ChatGPT, and enter that code once.
3. In **Staff access**, add each other staff member's ChatGPT account email.
4. The setup code is accepted only while no active staff account exists. Do not reuse or share it after setup.

Optional outbound email support uses `RESEND_API_KEY` and `EMAIL_FROM` as server-side Site secrets. Sending is separate from approval and is unavailable until both are configured. The app does not claim delivery unless the provider returns success.

## Safe document tests

Use only the four fictional PDFs in `public/demo-docs/`:

- Passport A: Ali Khan, expires 10 Mar 2030 — expected check: OK.
- Passport B: Ali Khan, expired 1 Jan 2025 — expected check: expired.
- Transcript: Ali Ahmed, marks 78% — expected check for Ali Khan: name mismatch.
- IELTS result: Ayesha Noor, score 7.0 — expected check: OK.

The upload form verifies actual PDF/JPG/PNG signatures and a 5 MB size limit. It compares the name, passport expiry and IELTS score that the student enters. **It does not OCR or inspect the visual contents of an uploaded file.** Staff still need to open and review each original file before marking it verified.

## Assistant and reminder behavior

The catalog assistant is deterministic. It retrieves facts from the saved program rows for fees, deadlines, minimum marks, IELTS scores and document lists. If it cannot match an office record, it drafts a request for a counselor to check. It does not use a generative-model API, promise admission or visa outcomes, or send a message automatically.

The follow-up scan finds leads with no reply for at least three days and program deadlines in the next 14 days. It creates draft tasks/messages in D1. A staff member must run the scan and approve each message; a recurring Cloudflare Cron or WhatsApp/Facebook integration is not configured in this project.

## Main data tables

`universities`, `leads`, `messages`, `documents`, `followups`, `staff_users`, `audit_log`, and `rate_limits` are defined in `db/schema.ts`; the generated SQL is in `drizzle/`. The staff-only **Database** page shows bounded read-only rows from the office tables. The Site's database viewer can also inspect the deployed D1 database.

## Tests

`pnpm test` checks inquiry normalization/validation, the supplied document cases, quiet-student detection, and the approval/source guardrails in catalog drafts. These are domain tests; they do not replace end-to-end testing of a configured mail provider or platform sign-in.
